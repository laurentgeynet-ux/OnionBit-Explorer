# 📜 Journal de Vol Permanent & Fiches Détaillées : Équipe 2 (JS / SPAs)

*Ce document conserve l'intégralité des vols sans jamais rien écraser. Chaque vol ajoute sa ligne au tableau récapitulatif ET sa fiche technique détaillée ci-dessous.*

---

## 📊 Tableau Récapitulatif Chronologique (27 vols)

| N° | Horodatage | Site internet | Statut | Poids Frame | Diagnostic / Mur détecté |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 11:55:11 | `https://todomvc.com/` | **🧱 MUR_JS** | 11267.2 Ko | [Voir Détail #1](#vol-1--todomvccom) — TypeError: toLowerCase is not a function |
| 2 | 2026-10-26 11:55:26 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | [Voir Détail #2](#vol-2--todomvccomexamplesvanillajs) — HTTP 404 Not Found |
| 3 | 2026-10-26 11:56:50 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | [Voir Détail #3](#vol-3--todomvccomexamplesbackbone) — Rendu nominal |
| 4 | 2026-10-26 11:57:18 | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349.0 Ko | [Voir Détail #4](#vol-4--danilowozcom) — Journal rejeté why=NoBaseline |
| 5 | 2026-10-26 11:57:54 | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | [Voir Détail #5](#vol-5--v2vuejsorg) — Journal rejeté why=UnmappedKey |
| 6 | 2026-10-26 11:58:13 | `https://todomvc.com/` | **🧱 MUR_JS** | 11267.2 Ko | [Voir Détail #6](#vol-6--todomvccom) — TypeError: cannot read cssRules of Undefined |
| 7 | 2026-10-26 11:59:41 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | [Voir Détail #7](#vol-7--todomvccomexamplesvanillajs) — HTTP 404 |
| 8 | 2026-10-26 11:59:56 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | [Voir Détail #8](#vol-8--todomvccomexamplesbackbone) — Rendu nominal |
| 9 | 2026-10-26 12:00:16 | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349.0 Ko | [Voir Détail #9](#vol-9--danilowozcom) — Journal rejeté why=NoBaseline |
| 10 | 2026-10-26 12:00:34 | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | [Voir Détail #10](#vol-10--v2vuejsorg) — Journal rejeté why=UnmappedKey |
| 11 | 2026-10-26 12:02:14 | `https://todomvc.com/` | **🧱 MUR_JS** | 11267.2 Ko | [Voir Détail #11](#vol-11--todomvccom) — Mur jQuery persistant |
| 12 | 2026-10-26 12:02:43 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | [Voir Détail #12](#vol-12--todomvccomexamplesvanillajs) — HTTP 404 |
| 13 | 2026-10-26 12:03:06 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | [Voir Détail #13](#vol-13--todomvccomexamplesbackbone) — Rendu nominal |
| 14 | 2026-10-26 12:03:15 | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349.0 Ko | [Voir Détail #14](#vol-14--danilowozcom) — Journal rejeté why=NoBaseline |
| 15 | 2026-10-26 12:04:49 | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | [Voir Détail #15](#vol-15--v2vuejsorg) — Journal rejeté why=UnmappedKey |
| 16 | 2026-10-26 12:05:10 | `https://todomvc.com/` | **🧱 MUR_JS** | 11267.2 Ko | [Voir Détail #16](#vol-16--todomvccom) — Mur jQuery persistant |
| 17 | 2026-10-26 12:05:35 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | [Voir Détail #17](#vol-17--todomvccomexamplesvanillajs) — HTTP 404 |
| 18 | 2026-10-26 12:06:00 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | [Voir Détail #18](#vol-18--todomvccomexamplesbackbone) — Rendu nominal |
| 19 | 2026-10-26 12:07:35 | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349.0 Ko | [Voir Détail #19](#vol-19--danilowozcom) — Journal rejeté why=NoBaseline |
| 20 | 2026-10-26 12:07:59 | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | [Voir Détail #20](#vol-20--v2vuejsorg) — Journal rejeté why=UnmappedKey |
| 21 | 2026-10-26 12:08:24 | `https://todomvc.com/` | **🧱 MUR_JS** | 11267.2 Ko | [Voir Détail #21](#vol-21--todomvccom) — Mur jQuery persistant |
| 22 | 2026-10-26 12:08:37 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | [Voir Détail #22](#vol-22--todomvccomexamplesvanillajs) — HTTP 404 |
| 23 | 2026-10-26 12:10:02 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | [Voir Détail #23](#vol-23--todomvccomexamplesbackbone) — Rendu nominal |
| 24 | 2026-10-26 12:10:19 | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349.0 Ko | [Voir Détail #24](#vol-24--danilowozcom) — Journal rejeté why=NoBaseline |
| 25 | 2026-10-26 12:10:56 | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | [Voir Détail #25](#vol-25--v2vuejsorg) — Journal rejeté why=UnmappedKey |
| 26 | 2026-10-26 12:21:50 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | [Voir Détail #26](#vol-26--todomvccomexamplesbackbone) — Rendu nominal |
| 27 | 2026-10-26 12:22:16 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | [Voir Détail #27](#vol-27--danilowozcom) — Rendu nominal |

---

## 🔍 Fiches Techniques Détaillées des Vols & Murs Rencontrés

### <a id="vol-1--todomvccom"></a>Vol #1 — `https://todomvc.com/` (2026-10-26 11:55:11)
- **Cible** : TodoMVC Hub (jQuery 2.1.4, PrefixFree, Bootstrap)
- **Statut** : 🧱 MUR_JS
- **Poids Frame** : 11 267.2 Ko
- **Description du blocage** :  
  Le script principal `jquery.min.js` tente de normaliser les propriétés DOM via `jQuery.propFix` en appelant :
  ```javascript
  jQuery.each(["cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"], function(){
      jQuery.propFix[this.toLowerCase()] = this;
  });
  ```
- **Stacktrace brute capturée** :
  ```text
  2026-10-26T10:44:31.048077Z INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=452 ok=false
  2026-10-26T10:44:31.048125Z DEBUG explorer_core::session::js_glue: script en échec tab=1 error=exception js : TypeError: `toLowerCase` is not a function (on Object)
      at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:4:1681)
      at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:2698)
  ```
- **Diagnostic Code Source Rust** :  
  Fichier `crates/explorer-jscore/src/interp/mod.rs` (fonction `call_script_body`, lignes 5542–5546).  
  En mode non-strict (sloppy), quand `this` est une primitive (`Value::Str("contentEditable")`), le moteur assigne `Value::Obj(self.global)` (`window`) au lieu d'encapsuler la chaîne primitive dans un wrapper `String` via `ToObject(this)` (spécification ECMA § 9.2.1.2). L'appel `window.toLowerCase()` échoue donc fatalement.
- **Reproduction minimale pour l'Agent 3 (Test TDD)** :
  ```javascript
  var res = (function() { return this.toLowerCase(); }).call("HELLO");
  if (res !== "hello") throw new Error("this n'est pas boxé en String");
  ```

---

### <a id="vol-2--todomvccomexamplesvanillajs"></a>Vol #2 — `https://todomvc.com/examples/vanillajs/` (2026-10-26 11:55:26)
- **Cible** : TodoMVC Vanilla JavaScript
- **Statut** : 🔴 FAIL (Erreur HTTP 404)
- **Analyse** : TodoMVC a restructuré ses répertoires exemples en `examples/javascript-es6/`. L'URL doit être actualisée dans la cible de patrouille.

---

### <a id="vol-3--todomvccomexamplesbackbone"></a>Vol #3 — `https://todomvc.com/examples/backbone/` (2026-10-26 11:56:50)
- **Cible** : TodoMVC Backbone.js
- **Statut** : 🟢 OK
- **Poids Frame** : 1 165.4 Ko
- **Analyse** : Chargement de la bibliothèque Backbone, initialisation des modèles et des collections MVC sans crash. La liste de tâches est correctement affichée.

---

### <a id="vol-4--danilowozcom"></a>Vol #4 — `https://danilowoz.com/` (2026-10-26 11:57:18)
- **Cible** : Portfolio interactif React / CSS-in-JS
- **Statut** : ⚠️ REPLI_DOM (Dégradation gracieuse)
- **Poids Frame** : 6 349.0 Ko
- **Log intercepté** :
  ```text
  WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=NoBaseline
  ```
- **Diagnostic** : Le journal incrémental n'a pas pu identifier la référence de base (`NoBaseline`). Le moteur s'est replié sur un re-calcul complet sans planter la session.

---

### <a id="vol-5--v2vuejsorg"></a>Vol #5 — `https://v2.vuejs.org/` (2026-10-26 11:57:54)
- **Cible** : Documentation Vue.js v2
- **Statut** : ⚠️ REPLI_DOM
- **Poids Frame** : 7 851.2 Ko
- **Log intercepté** :
  ```text
  WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=UnmappedKey
  ```
- **Diagnostic** : Une clé d'attribut ou de nœud n'a pas été trouvée dans le miroir. Le moteur applique le re-parse de sécurité ADR-0025.

---

### <a id="vol-6--todomvccom"></a>Vol #6 — `https://todomvc.com/` (2026-10-26 11:58:13)
- **Cible** : TodoMVC
- **Statut** : 🧱 MUR_JS
- **Description du 2ème mur (PrefixFree)** :  
  Accès à `element.sheet.cssRules` sur les balises `<style>` et `<link rel="stylesheet">`.
- **Trace brute** :
  ```text
  DEBUG explorer_core::session::js_glue: script en échec tab=1 error=exception js : TypeError: cannot read `cssRules` of Undefined
      at s (https://todomvc.com/bower_components/prefixfree/prefixfree.min.js:5:5533)
  ```
- **Diagnostic Code Source Rust** :  
  Fichier `crates/explorer-jscore/src/dom_host.rs`. Le getter `.sheet` doit renvoyer l'objet `CSSStyleSheet` correspondant.
| 2026-10-26 12:24:28 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:24:43 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:25:03 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:25:34 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:27:14 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:27:37 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:27:56 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:28:06 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:29:34 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:29:56 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:30:31 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:30:51 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:32:17 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:32:38 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:33:03 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:33:16 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:34:41 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:35:08 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:35:45 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:36:05 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:37:33 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:37:48 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:38:08 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:38:25 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:40:06 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:40:37 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:41:02 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:41:12 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:42:41 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:43:02 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:43:28 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:43:48 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:45:24 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:45:49 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:46:14 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:46:28 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:47:52 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:48:09 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:48:46 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:49:11 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 2026-10-26 12:50:42 | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 2026-10-26 12:50:56 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 2026-10-26 12:51:16 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 2026-10-26 12:51:33 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 2026-10-26 12:53:06 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
