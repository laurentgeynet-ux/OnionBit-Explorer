# 🛰️ RAPPORT DE MISSION EN VOL : ÉQUIPE 3 : FORMULAIRES, AUTH & E-COMMERCE (SITES INÉDITS)

*Rapport d'exploration inédit (100% nouveaux sites). Aucun ancien site validé.*

## 📋 Tableau Récapitulatif Chronologique

| N° | Horodatage | Site internet inédit | Statut | Poids Frame | Constat / Mur détecté |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 12:43:26 | `https://books.toscrape.com/` | **🟢 OK** | 6782.7 Ko | Rendu nominal réussi |
| 2 | 2026-10-26 12:44:03 | `https://quotes.toscrape.com/login` | **🟢 OK** | 1364.0 Ko | Rendu nominal réussi |
| 11 | 2026-10-26 12:44:26 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal réussi |
| 3 | 2026-10-26 12:44:43 | `https://postman-echo.com/` | **🟢 OK** | 1220.0 Ko | Rendu nominal réussi |
| 12 | 2026-10-26 12:44:59 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal réussi |
| 4 | 2026-10-26 12:45:29 | `https://gitlab.com/users/sign_in` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 403 |
| 13 | 2026-10-26 12:45:35 | `https://books.toscrape.com/` | **🟢 OK** | 6782.7 Ko | Rendu nominal réussi |
| 14 | 2026-10-26 12:46:06 | `https://quotes.toscrape.com/login` | **🟢 OK** | 1364.0 Ko | Rendu nominal réussi |
| 15 | 2026-10-26 12:46:42 | `https://postman-echo.com/` | **🟢 OK** | 1220.0 Ko | Rendu nominal réussi |
| 16 | 2026-10-26 12:47:20 | `https://github.com/login` | **🟢 OK** | 1302.7 Ko | Rendu nominal réussi |
| 17 | 2026-10-26 12:48:15 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal réussi |
| 5 | 2026-10-26 12:45:58 | `https://wordpress.org/support/users/login/` | **🟢 OK** | 6677.5 Ko | Rendu nominal réussi |
| 18 | 2026-10-26 12:49:00 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal réussi |
| 19 | 2026-10-26 12:50:50 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal réussi |
| 20 | 2026-10-26 12:51:45 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal réussi |
| 21 | 2026-10-26 12:52:30 | `https://books.toscrape.com/` | **🟢 OK** | 6782.7 Ko | Rendu nominal réussi |
| 22 | 2026-10-26 12:53:13 | `https://quotes.toscrape.com/login` | **🟢 OK** | 1364.0 Ko | Rendu nominal réussi |


## 🔍 Fiches Détaillées par Vol

---

### ✈️ Vol #1 — `https://books.toscrape.com/`
- **Horodatage** : 2026-10-26 12:43:26
- **URL testée (Inédite)** : https://books.toscrape.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-26_EQUIPE_3_FORMS_books.toscrape.com_.png` (6782.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-26_EQUIPE_3_FORMS_books.toscrape.com_.png â€” 6945488 octets

2026-10-26T11:43:26.764229Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:27.441249Z  INFO explorer_core::session::apply: apply: cascade ms=20
2026-10-26T11:43:27.453867Z  INFO explorer_core::session::apply: apply: boxtree ms=33
2026-10-26T11:43:27.605221Z  INFO explorer_core::session::apply: apply: layout ms=184
2026-10-26T11:43:27.709460Z  INFO explorer_core::session::apply: apply: repaint ms=288
2026-10-26T11:43:27.721432Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=957
2026-10-26T11:43:27.727791Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=963
2026-10-26T11:43:29.346928Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2582
2026-10-26T11:43:29.347723Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=102
2026-10-26T11:43:29.348232Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:29.348258Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31819
2026-10-26T11:43:29.381849Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=33 ok=false
2026-10-26T11:43:29.383692Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=13966
2026-10-26T11:43:29.387015Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=false
2026-10-26T11:43:29.388151Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=55328
2026-10-26T11:43:29.434220Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=46 ok=false
2026-10-26T11:43:29.438778Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31995
2026-10-26T11:43:29.447963Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=9 ok=false
2026-10-26T11:43:29.450522Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=124
2026-10-26T11:43:29.450672Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:43:30.019612Z  INFO explorer_core::session::apply: apply: cascade ms=382
2026-10-26T11:43:30.057851Z  INFO explorer_core::session::apply: apply: boxtree ms=420
2026-10-26T11:43:30.335458Z  INFO explorer_core::session::apply: apply: layout ms=697
2026-10-26T11:43:30.697730Z  INFO explorer_core::session::apply: apply: repaint ms=1060
2026-10-26T11:43:31.437091Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:43:32.232331Z  INFO explorer_core::session::apply: apply: cascade ms=385
2026-10-26T11:43:32.270775Z  INFO explorer_core::session::apply: apply: boxtree ms=423
2026-10-26T11:43:32.359710Z  INFO explorer_core::session::apply: apply: layout ms=512
2026-10-26T11:43:32.685113Z  INFO explorer_core::session::apply: apply: repaint ms=838
2026-10-26T11:43:32.718313Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1281
[journal : 0 appliquÃ©s / 0 replis / 27 classÃ©es]
```

---

### ✈️ Vol #2 — `https://quotes.toscrape.com/login`
- **Horodatage** : 2026-10-26 12:44:03
- **URL testée (Inédite)** : https://quotes.toscrape.com/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-03_EQUIPE_3_FORMS_quotes.toscrape.com_login.png` (1364.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-03_EQUIPE_3_FORMS_quotes.toscrape.com_login.png â€” 1396706 octets

2026-10-26T11:44:03.293508Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:03.830307Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=536
2026-10-26T11:44:03.830932Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=537
2026-10-26T11:44:04.816918Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1523
2026-10-26T11:44:04.887945Z  INFO explorer_core::session::apply: apply: cascade ms=70
2026-10-26T11:44:04.889492Z  INFO explorer_core::session::apply: apply: boxtree ms=72
2026-10-26T11:44:04.918449Z  INFO explorer_core::session::apply: apply: layout ms=101
2026-10-26T11:44:04.951689Z  INFO explorer_core::session::apply: apply: repaint ms=134
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #11 — `https://html.duckduckgo.com/html/`
- **Horodatage** : 2026-10-26 12:44:26
- **URL testée** : https://html.duckduckgo.com/html/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-26_EQUIPE_3_FORMS_html.duckduckgo.com_html_.png` (2274.8 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-26_EQUIPE_3_FORMS_html.duckduckgo.com_html_.png â€” 2329366 octets

2026-10-26T11:44:26.328014Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:26.589156Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=261
2026-10-26T11:44:26.589724Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=261
2026-10-26T11:44:28.079222Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1751
2026-10-26T11:44:28.128567Z  INFO explorer_core::session::apply: apply: cascade ms=49
2026-10-26T11:44:28.230623Z  INFO explorer_core::session::apply: apply: boxtree ms=151
2026-10-26T11:44:28.240411Z  INFO explorer_core::session::apply: apply: layout ms=160
2026-10-26T11:44:28.446237Z  INFO explorer_core::session::apply: apply: repaint ms=366
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #3 — `https://postman-echo.com/`
- **Horodatage** : 2026-10-26 12:44:43
- **URL testée (Inédite)** : https://postman-echo.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-43_EQUIPE_3_FORMS_postman-echo.com_.png` (1220.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-43_EQUIPE_3_FORMS_postman-echo.com_.png â€” 1249287 octets

2026-10-26T11:44:43.538955Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:44.528106Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=989
2026-10-26T11:44:44.528947Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=990
2026-10-26T11:44:46.747571Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=3208
2026-10-26T11:44:46.747693Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=61397
2026-10-26T11:44:46.843563Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=95 ok=true
2026-10-26T11:44:46.843612Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1148
2026-10-26T11:44:46.846799Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:44:46.846826Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4680
2026-10-26T11:44:46.848784Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:44:46.848809Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=36
2026-10-26T11:44:46.848896Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:44:46.848913Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=581
2026-10-26T11:44:46.849288Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:44:46.849305Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1983
2026-10-26T11:44:46.850329Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:44:46.850345Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=631
2026-10-26T11:44:46.850820Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:44:46.850843Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=96402
2026-10-26T11:44:46.888214Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=37 ok=true
2026-10-26T11:44:46.888274Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=8679622
2026-10-26T11:44:53.092078Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6203 ok=false
2026-10-26T11:44:53.554503Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=21835
2026-10-26T11:44:53.662255Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=107 ok=true
2026-10-26T11:44:53.724554Z  INFO explorer_core::session::apply: apply: cascade ms=34
2026-10-26T11:44:53.760990Z  INFO explorer_core::session::apply: apply: boxtree ms=70
2026-10-26T11:44:53.767726Z  INFO explorer_core::session::apply: apply: layout ms=77
2026-10-26T11:44:53.790932Z  INFO explorer_core::session::apply: apply: repaint ms=100
2026-10-26T11:44:53.803391Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:44:53.881685Z  INFO explorer_core::session::apply: apply: cascade ms=30
2026-10-26T11:44:53.882482Z  INFO explorer_core::session::apply: apply: boxtree ms=30
2026-10-26T11:44:53.885255Z  INFO explorer_core::session::apply: apply: layout ms=33
2026-10-26T11:44:53.902796Z  INFO explorer_core::session::apply: apply: repaint ms=51
2026-10-26T11:44:53.903542Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=100
2026-10-26T11:44:54.120494Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:44:54.120600Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:44:54.121078Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:44:54.925768Z  INFO explorer_core::session::apply: apply: cascade ms=783
2026-10-26T11:44:54.926643Z  INFO explorer_core::session::apply: apply: boxtree ms=784
2026-10-26T11:44:54.929419Z  INFO explorer_core::session::apply: apply: layout ms=787
2026-10-26T11:44:54.951503Z  INFO explorer_core::session::apply: apply: repaint ms=809
2026-10-26T11:44:54.952246Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=831
[journal : 0 appliquÃ©s / 1 replis / 1 classÃ©es]
```

---

### ✈️ Vol #12 — `https://lobste.rs/login`
- **Horodatage** : 2026-10-26 12:44:59
- **URL testée** : https://lobste.rs/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-59_EQUIPE_3_FORMS_lobste.rs_login.png` (1215.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-59_EQUIPE_3_FORMS_lobste.rs_login.png â€” 1244217 octets

2026-10-26T11:44:59.340833Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:59.856081Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=515
2026-10-26T11:44:59.856904Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=516
2026-10-26T11:45:00.552312Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1211
2026-10-26T11:45:00.595885Z  INFO explorer_core::session::apply: apply: cascade ms=41
2026-10-26T11:45:00.599030Z  INFO explorer_core::session::apply: apply: boxtree ms=44
2026-10-26T11:45:00.663268Z  INFO explorer_core::session::apply: apply: layout ms=108
2026-10-26T11:45:00.713426Z  INFO explorer_core::session::apply: apply: repaint ms=158
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #4 — `https://gitlab.com/users/sign_in`
- **Horodatage** : 2026-10-26 12:45:29
- **URL testée (Inédite)** : https://gitlab.com/users/sign_in
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-45-29_EQUIPE_3_FORMS_gitlab.com_users_sign_in.png` (0.0 Ko)
- **Constat technique** : erreur : HTTP 403

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:45:29.843346Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:29.992947Z  INFO explorer_core::session::apply: apply: cascade ms=3
2026-10-26T11:45:29.993221Z  INFO explorer_core::session::apply: apply: boxtree ms=3
2026-10-26T11:45:30.036173Z  INFO explorer_core::session::apply: apply: layout ms=46
2026-10-26T11:45:30.062089Z  INFO explorer_core::session::apply: apply: repaint ms=72
erreur : HTTP 403
```

---

### ✈️ Vol #13 — `https://books.toscrape.com/`
- **Horodatage** : 2026-10-26 12:45:35
- **URL testée** : https://books.toscrape.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-35_EQUIPE_3_FORMS_books.toscrape.com_.png` (6782.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-35_EQUIPE_3_FORMS_books.toscrape.com_.png â€” 6945488 octets

2026-10-26T11:45:35.993826Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:36.663791Z  INFO explorer_core::session::apply: apply: cascade ms=23
2026-10-26T11:45:36.679619Z  INFO explorer_core::session::apply: apply: boxtree ms=39
2026-10-26T11:45:36.863306Z  INFO explorer_core::session::apply: apply: layout ms=222
2026-10-26T11:45:36.988588Z  INFO explorer_core::session::apply: apply: repaint ms=347
2026-10-26T11:45:36.999637Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=1005
2026-10-26T11:45:37.006204Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=1012
2026-10-26T11:45:38.419812Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2426
2026-10-26T11:45:38.420596Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=102
2026-10-26T11:45:38.421163Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:38.421189Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31819
2026-10-26T11:45:38.454451Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=33 ok=false
2026-10-26T11:45:38.456303Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=13966
2026-10-26T11:45:38.459756Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=false
2026-10-26T11:45:38.460910Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=55328
2026-10-26T11:45:38.506836Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=45 ok=false
2026-10-26T11:45:38.511504Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31995
2026-10-26T11:45:38.520280Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=8 ok=false
2026-10-26T11:45:38.522793Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=124
2026-10-26T11:45:38.522913Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:45:39.085661Z  INFO explorer_core::session::apply: apply: cascade ms=377
2026-10-26T11:45:39.123704Z  INFO explorer_core::session::apply: apply: boxtree ms=415
2026-10-26T11:45:39.399756Z  INFO explorer_core::session::apply: apply: layout ms=691
2026-10-26T11:45:39.761938Z  INFO explorer_core::session::apply: apply: repaint ms=1053
2026-10-26T11:45:40.523872Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:45:41.330189Z  INFO explorer_core::session::apply: apply: cascade ms=395
2026-10-26T11:45:41.368145Z  INFO explorer_core::session::apply: apply: boxtree ms=433
2026-10-26T11:45:41.456353Z  INFO explorer_core::session::apply: apply: layout ms=521
2026-10-26T11:45:41.782114Z  INFO explorer_core::session::apply: apply: repaint ms=847
2026-10-26T11:45:41.815494Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1291
[journal : 0 appliquÃ©s / 0 replis / 27 classÃ©es]
```

---

### ✈️ Vol #14 — `https://quotes.toscrape.com/login`
- **Horodatage** : 2026-10-26 12:46:06
- **URL testée** : https://quotes.toscrape.com/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-46-06_EQUIPE_3_FORMS_quotes.toscrape.com_login.png` (1364.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-46-06_EQUIPE_3_FORMS_quotes.toscrape.com_login.png â€” 1396706 octets

2026-10-26T11:46:06.484566Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:07.016110Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=531
2026-10-26T11:46:07.016655Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=532
2026-10-26T11:46:07.879600Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1395
2026-10-26T11:46:07.953878Z  INFO explorer_core::session::apply: apply: cascade ms=74
2026-10-26T11:46:07.955508Z  INFO explorer_core::session::apply: apply: boxtree ms=75
2026-10-26T11:46:07.985509Z  INFO explorer_core::session::apply: apply: layout ms=105
2026-10-26T11:46:08.018802Z  INFO explorer_core::session::apply: apply: repaint ms=138
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #15 — `https://postman-echo.com/`
- **Horodatage** : 2026-10-26 12:46:42
- **URL testée** : https://postman-echo.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-46-42_EQUIPE_3_FORMS_postman-echo.com_.png` (1220.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-46-42_EQUIPE_3_FORMS_postman-echo.com_.png â€” 1249287 octets

2026-10-26T11:46:42.538981Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:43.505581Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=966
2026-10-26T11:46:43.506380Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=967
2026-10-26T11:46:45.584270Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=3045
2026-10-26T11:46:45.584397Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=61397
2026-10-26T11:46:45.679663Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=95 ok=true
2026-10-26T11:46:45.679715Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1148
2026-10-26T11:46:45.683441Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:46:45.683487Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4680
2026-10-26T11:46:45.685519Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:46:45.685543Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=36
2026-10-26T11:46:45.685666Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:45.685683Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=581
2026-10-26T11:46:45.686113Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:45.686129Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1983
2026-10-26T11:46:45.687182Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:46:45.687204Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=631
2026-10-26T11:46:45.687690Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:45.687713Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=96402
2026-10-26T11:46:45.727375Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=39 ok=true
2026-10-26T11:46:45.727440Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=8679622
2026-10-26T11:46:51.793046Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6065 ok=false
2026-10-26T11:46:52.252621Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=21835
2026-10-26T11:46:52.360837Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=108 ok=true
2026-10-26T11:46:52.418840Z  INFO explorer_core::session::apply: apply: cascade ms=29
2026-10-26T11:46:52.455299Z  INFO explorer_core::session::apply: apply: boxtree ms=66
2026-10-26T11:46:52.462134Z  INFO explorer_core::session::apply: apply: layout ms=73
2026-10-26T11:46:52.485326Z  INFO explorer_core::session::apply: apply: repaint ms=96
2026-10-26T11:46:52.496822Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:46:52.573435Z  INFO explorer_core::session::apply: apply: cascade ms=30
2026-10-26T11:46:52.574332Z  INFO explorer_core::session::apply: apply: boxtree ms=30
2026-10-26T11:46:52.577163Z  INFO explorer_core::session::apply: apply: layout ms=33
2026-10-26T11:46:52.594531Z  INFO explorer_core::session::apply: apply: repaint ms=51
2026-10-26T11:46:52.595272Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=98
2026-10-26T11:46:52.812866Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:46:52.812969Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:46:52.813449Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:46:53.627082Z  INFO explorer_core::session::apply: apply: cascade ms=792
2026-10-26T11:46:53.627959Z  INFO explorer_core::session::apply: apply: boxtree ms=793
2026-10-26T11:46:53.630740Z  INFO explorer_core::session::apply: apply: layout ms=796
2026-10-26T11:46:53.653317Z  INFO explorer_core::session::apply: apply: repaint ms=818
2026-10-26T11:46:53.654056Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=840
[journal : 0 appliquÃ©s / 1 replis / 1 classÃ©es]
```

---

### ✈️ Vol #16 — `https://github.com/login`
- **Horodatage** : 2026-10-26 12:47:20
- **URL testée** : https://github.com/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-47-20_EQUIPE_3_FORMS_github.com_login.png` (1302.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-47-20_EQUIPE_3_FORMS_github.com_login.png â€” 1333921 octets

2026-10-26T11:47:20.786376Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:47:21.164966Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=378
2026-10-26T11:47:21.168333Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=381
2026-10-26T11:47:27.747589Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=6961
2026-10-26T11:47:27.986545Z DEBUG explorer_jscore::dom_host: customElements.define name=live-region-bc22a49e-5b01-4899-ac30-7b39472ece66
2026-10-26T11:47:28.205308Z DEBUG explorer_jscore::dom_host: customElements.define name=include-fragment
2026-10-26T11:47:28.205920Z DEBUG explorer_jscore::dom_host: customElements.define name=remote-input
2026-10-26T11:47:28.207584Z DEBUG explorer_jscore::dom_host: customElements.define name=action-list
2026-10-26T11:47:28.211545Z DEBUG explorer_jscore::dom_host: customElements.define name=action-bar
2026-10-26T11:47:28.212335Z DEBUG explorer_jscore::dom_host: customElements.define name=details-menu
2026-10-26T11:47:28.212719Z DEBUG explorer_jscore::dom_host: customElements.define name=anchored-position
2026-10-26T11:47:28.212955Z DEBUG explorer_jscore::dom_host: customElements.define name=dialog-helper
2026-10-26T11:47:28.220118Z DEBUG explorer_jscore::dom_host: customElements.define name=focus-group
2026-10-26T11:47:28.221039Z DEBUG explorer_jscore::dom_host: customElements.define name=scrollable-region
2026-10-26T11:47:28.224924Z DEBUG explorer_jscore::dom_host: customElements.define name=modal-dialog
2026-10-26T11:47:28.226090Z DEBUG explorer_jscore::dom_host: customElements.define name=nav-list
2026-10-26T11:47:28.227207Z DEBUG explorer_jscore::dom_host: customElements.define name=nav-list-group
2026-10-26T11:47:28.228686Z DEBUG explorer_jscore::dom_host: customElements.define name=segmented-control
2026-10-26T11:47:28.230162Z DEBUG explorer_jscore::dom_host: customElements.define name=toggle-switch
2026-10-26T11:47:28.232287Z DEBUG explorer_jscore::dom_host: customElements.define name=tool-tip
2026-10-26T11:47:28.235925Z DEBUG explorer_jscore::dom_host: customElements.define name=x-banner
2026-10-26T11:47:28.236786Z DEBUG explorer_jscore::dom_host: customElements.define name=auto-complete
2026-10-26T11:47:28.237271Z DEBUG explorer_jscore::dom_host: customElements.define name=clipboard-copy
2026-10-26T11:47:28.243409Z DEBUG explorer_jscore::dom_host: customElements.define name=relative-time
2026-10-26T11:47:28.243743Z DEBUG explorer_jscore::dom_host: customElements.define name=tab-container
2026-10-26T11:47:28.244596Z DEBUG explorer_jscore::dom_host: customElements.define name=primer-multi-input
2026-10-26T11:47:28.245266Z DEBUG explorer_jscore::dom_host: customElements.define name=auto-check
2026-10-26T11:47:28.247614Z DEBUG explorer_jscore::dom_host: customElements.define name=primer-text-field
2026-10-26T11:47:28.248835Z DEBUG explorer_jscore::dom_host: customElements.define name=primer-text-area
2026-10-26T11:47:28.249869Z DEBUG explorer_jscore::dom_host: customElements.define name=toggle-switch-input
2026-10-26T11:47:28.251307Z DEBUG explorer_jscore::dom_host: customElements.define name=action-menu
2026-10-26T11:47:28.252400Z DEBUG explorer_jscore::dom_host: customElements.define name=live-region
2026-10-26T11:47:28.255374Z DEBUG explorer_jscore::dom_host: customElements.define name=select-panel
2026-10-26T11:47:28.256410Z DEBUG explorer_jscore::dom_host: customElements.define name=details-toggle
2026-10-26T11:47:28.257622Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view
2026-10-26T11:47:28.258709Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view-icon-pair
2026-10-26T11:47:28.261496Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view-sub-tree-node
2026-10-26T11:47:28.262171Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view-include-fragment
2026-10-26T11:47:28.262785Z DEBUG explorer_jscore::dom_host: customElements.define name=details-dialog
2026-10-26T11:47:28.265394Z DEBUG explorer_jscore::dom_host: customElements.define name=file-attachment
2026-10-26T11:47:28.265866Z DEBUG explorer_jscore::dom_host: customElements.define name=filter-input
2026-10-26T11:47:28.276640Z DEBUG explorer_jscore::dom_host: customElements.define name=g-emoji
2026-10-26T11:47:28.277411Z DEBUG explorer_jscore::dom_host: customElements.define name=md-header
2026-10-26T11:47:28.277597Z DEBUG explorer_jscore::dom_host: customElements.define name=md-bold
2026-10-26T11:47:28.277800Z DEBUG explorer_jscore::dom_host: customElements.define name=md-italic
2026-10-26T11:47:28.277973Z DEBUG explorer_jscore::dom_host: customElements.define name=md-quote
2026-10-26T11:47:28.278146Z DEBUG explorer_jscore::dom_host: customElements.define name=md-code
2026-10-26T11:47:28.278318Z DEBUG explorer_jscore::dom_host: customElements.define name=md-link
2026-10-26T11:47:28.278489Z DEBUG explorer_jscore::dom_host: customElements.define name=md-image
2026-10-26T11:47:28.278665Z DEBUG explorer_jscore::dom_host: customElements.define name=md-unordered-list
2026-10-26T11:47:28.278840Z DEBUG explorer_jscore::dom_host: customElements.define name=md-ordered-list
2026-10-26T11:47:28.279013Z DEBUG explorer_jscore::dom_host: customElements.define name=md-task-list
2026-10-26T11:47:28.279188Z DEBUG explorer_jscore::dom_host: customElements.define name=md-mention
2026-10-26T11:47:28.279359Z DEBUG explorer_jscore::dom_host: customElements.define name=md-ref
2026-10-26T11:47:28.279553Z DEBUG explorer_jscore::dom_host: customElements.define name=md-strikethrough
2026-10-26T11:47:28.279761Z DEBUG explorer_jscore::dom_host: customElements.define name=markdown-toolbar
2026-10-26T11:47:28.280534Z DEBUG explorer_jscore::dom_host: customElements.define name=task-lists
2026-10-26T11:47:28.284974Z DEBUG explorer_jscore::dom_host: customElements.define name=text-expander
2026-10-26T11:47:28.285316Z DEBUG explorer_jscore::dom_host: customElements.define name=typing-effect
2026-10-26T11:47:28.285658Z DEBUG explorer_jscore::dom_host: customElements.define name=image-crop
2026-10-26T11:47:29.207765Z DEBUG explorer_jscore::dom_host: customElements.define name=batch-deferred-content
2026-10-26T11:47:29.505512Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-frame
2026-10-26T11:47:29.505701Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-stream
2026-10-26T11:47:29.505840Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-stream-source
2026-10-26T11:47:29.549359Z DEBUG explorer_jscore::dom_host: customElements.define name=webauthn-get
2026-10-26T11:47:29.562393Z DEBUG explorer_jscore::dom_host: customElements.define name=sudo-credential-options
2026-10-26T11:47:29.711766Z DEBUG explorer_jscore::dom_host: customElements.define name=collapsible-sidebar-widget
2026-10-26T11:47:29.714162Z DEBUG explorer_jscore::dom_host: customElements.define name=sidebar-memex-input
2026-10-26T11:47:29.742442Z DEBUG explorer_jscore::module: import() dynamique spec="./4f-128d9b1a702b1593.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:29.767572Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-l1-18d79a71714bc7ea.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:29.891894Z DEBUG explorer_jscore::dom_host: customElements.define name=actions-policy-popover
2026-10-26T11:47:29.894028Z DEBUG explorer_jscore::dom_host: customElements.define name=actions-policy-form
2026-10-26T11:47:29.897834Z DEBUG explorer_jscore::dom_host: customElements.define name=appearance-form
2026-10-26T11:47:29.899214Z DEBUG explorer_jscore::dom_host: customElements.define name=appearance-preview
2026-10-26T11:47:29.907933Z DEBUG explorer_jscore::dom_host: customElements.define name=default-location-setting
2026-10-26T11:47:29.922499Z DEBUG explorer_jscore::dom_host: customElements.define name=dependabot-alert-rule-form
2026-10-26T11:47:30.013488Z DEBUG explorer_jscore::dom_host: customElements.define name=retention-form
2026-10-26T11:47:30.023874Z DEBUG explorer_jscore::dom_host: customElements.define name=advanced-security-new-repos
2026-10-26T11:47:30.032112Z DEBUG explorer_jscore::dom_host: customElements.define name=selected-item-count
2026-10-26T11:47:30.034294Z DEBUG explorer_jscore::dom_host: customElements.define name=selected-item-list
2026-10-26T11:47:30.046188Z DEBUG explorer_jscore::dom_host: customElements.define name=fgpat-confirmation-dialog
2026-10-26T11:47:30.050032Z DEBUG explorer_jscore::dom_host: customElements.define name=pages-build-type
2026-10-26T11:47:30.051807Z DEBUG explorer_jscore::dom_host: customElements.define name=pages-jekyll-config
2026-10-26T11:47:30.053420Z DEBUG explorer_jscore::dom_host: customElements.define name=public-ip
2026-10-26T11:47:30.056519Z DEBUG explorer_jscore::dom_host: customElements.define name=waiting-form
2026-10-26T11:47:30.058646Z DEBUG explorer_jscore::dom_host: customElements.define name=social-account-editor
2026-10-26T11:47:31.698465Z  INFO explorer_core::session::apply: apply: cascade ms=942
2026-10-26T11:47:32.024789Z  INFO explorer_core::session::apply: apply: boxtree ms=1269
2026-10-26T11:47:32.085477Z  INFO explorer_core::session::apply: apply: layout ms=1329
2026-10-26T11:47:32.201372Z  INFO explorer_core::session::apply: apply: repaint ms=1445
2026-10-26T11:47:32.251534Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-webauthn-status-023639160ec7e00e.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.289552Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-select-panel-1db988c3b2debb9f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.314663Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-toggle-switch-d84c21582809dda9.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.323134Z DEBUG explorer_jscore::module: import() dynamique spec="./yg2-1ef73bfd680141dc.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.347993Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-cookie-consent-link-f9fd1ccb00a8c36f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.373288Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-ghcc-consent-47aaf7da7816fc53.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.398609Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-microsoft-analytics-7a0a6d4fa4773160.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.423619Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-webauthn-get-594ac3b363fd9c1e.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.448667Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-webauthn-subtle-2b94efccee7968f5.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.492065Z DEBUG explorer_jscore::module: import() dynamique spec="./primer-react-911369ee234690ef.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.523588Z DEBUG explorer_jscore::module: import() dynamique spec="./nc-28ebfc8e58bca42f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.538213Z DEBUG explorer_jscore::module: import() dynamique spec="./qmp-308230626a2aedb0.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.546328Z DEBUG explorer_jscore::module: import() dynamique spec="./t7l-423469c05c948a8b.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.554253Z DEBUG explorer_jscore::module: import() dynamique spec="./3s-ebbc335534e40b2a.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.562443Z DEBUG explorer_jscore::module: import() dynamique spec="./cnq-00f06287d057a2b3.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.570462Z DEBUG explorer_jscore::module: import() dynamique spec="./gw-4bf343b417f9ec19.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.602631Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-keyboard-shortcuts-dialog-6d857a36d55539c5.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.613427Z DEBUG explorer_jscore::module: import() dynamique spec="./hiz-0c55010ddab90e83.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.622399Z DEBUG explorer_jscore::module: import() dynamique spec="./660-1a37aa7115fadcc2.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.654412Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-sessions-auth-header-c738770fdf5f6f09.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:47:32.706637Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:47:34.699927Z  INFO explorer_core::session::apply: apply: cascade ms=977
2026-10-26T11:47:34.709153Z  INFO explorer_core::session::apply: apply: boxtree ms=987
2026-10-26T11:47:34.719285Z  INFO explorer_core::session::apply: apply: layout ms=997
2026-10-26T11:47:34.868591Z  INFO explorer_core::session::apply: apply: repaint ms=1146
2026-10-26T11:47:34.871437Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=2164
[journal : 0 appliquÃ©s / 0 replis / 4 classÃ©es]
```

---

### ✈️ Vol #17 — `https://news.ycombinator.com/login`
- **Horodatage** : 2026-10-26 12:48:15
- **URL testée** : https://news.ycombinator.com/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-48-15_EQUIPE_3_FORMS_news.ycombinator.com_login.png` (1173.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-48-15_EQUIPE_3_FORMS_news.ycombinator.com_login.png â€” 1201711 octets

2026-10-26T11:48:15.935501Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:48:16.624733Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=689
2026-10-26T11:48:16.625104Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=689
2026-10-26T11:48:16.627024Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=691
2026-10-26T11:48:16.633016Z  INFO explorer_core::session::apply: apply: cascade ms=5
2026-10-26T11:48:16.634154Z  INFO explorer_core::session::apply: apply: boxtree ms=7
2026-10-26T11:48:16.653437Z  INFO explorer_core::session::apply: apply: layout ms=26
2026-10-26T11:48:16.673493Z  INFO explorer_core::session::apply: apply: repaint ms=46
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #5 — `https://wordpress.org/support/users/login/`
- **Horodatage** : 2026-10-26 12:45:58
- **URL testée (Inédite)** : https://wordpress.org/support/users/login/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-58_EQUIPE_3_FORMS_wordpress.org_support_users_login_.png` (6677.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-58_EQUIPE_3_FORMS_wordpress.org_support_users_login_.png â€” 6837731 octets

2026-10-26T11:45:58.561876Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:59.723644Z  INFO explorer_core::session::apply: apply: cascade ms=233
2026-10-26T11:45:59.761776Z  INFO explorer_core::session::apply: apply: boxtree ms=271
2026-10-26T11:45:59.934453Z  INFO explorer_core::session::apply: apply: layout ms=443
2026-10-26T11:46:00.098951Z  INFO explorer_core::session::apply: apply: repaint ms=608
2026-10-26T11:46:00.106444Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=1544
2026-10-26T11:46:00.113961Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=1552
2026-10-26T11:47:38.412984Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=99851
2026-10-26T11:47:38.413577Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=341
2026-10-26T11:47:38.414577Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.414644Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=87553
2026-10-26T11:47:38.819612Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=404 ok=true
2026-10-26T11:47:38.819675Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=19346
2026-10-26T11:47:38.962956Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=143 ok=true
2026-10-26T11:47:38.963010Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=86
2026-10-26T11:47:38.963492Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.963544Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=72
2026-10-26T11:47:38.963913Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.963941Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=934
2026-10-26T11:47:38.975819Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=11 ok=true
2026-10-26T11:47:38.975856Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2157
2026-10-26T11:47:38.976629Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.976667Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=337
2026-10-26T11:47:38.976874Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.976898Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2725
2026-10-26T11:47:38.982471Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=5 ok=true
2026-10-26T11:47:38.982500Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=265
2026-10-26T11:47:38.982760Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.982776Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=139
2026-10-26T11:47:38.982887Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.982907Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1832
2026-10-26T11:47:38.994983Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=12 ok=true
2026-10-26T11:47:38.995011Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=180
2026-10-26T11:47:38.995159Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:38.995181Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=8505
2026-10-26T11:47:38.997117Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:47:39.081220Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1098
2026-10-26T11:47:39.082357Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:47:39.082387Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3812
2026-10-26T11:47:39.088330Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=5 ok=true
2026-10-26T11:47:39.088363Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1857
2026-10-26T11:47:39.089175Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:41.350585Z  INFO explorer_core::session::apply: apply: cascade ms=798
2026-10-26T11:47:41.859050Z  INFO explorer_core::session::apply: apply: boxtree ms=1307
2026-10-26T11:47:42.033645Z  INFO explorer_core::session::apply: apply: layout ms=1481
2026-10-26T11:47:42.255393Z  INFO explorer_core::session::apply: apply: repaint ms=1703
2026-10-26T11:47:45.331181Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:47:45.331278Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:47:45.341475Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:48:43.290747Z  INFO explorer_core::session::apply: apply: cascade ms=56739
2026-10-26T11:48:43.849507Z  INFO explorer_core::session::apply: apply: boxtree ms=57298
2026-10-26T11:48:43.887460Z  INFO explorer_core::session::apply: apply: layout ms=57336
2026-10-26T11:48:44.102141Z  INFO explorer_core::session::apply: apply: repaint ms=57551
2026-10-26T11:48:44.308192Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=58966
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #18 — `https://httpbin.org/forms/post`
- **Horodatage** : 2026-10-26 12:49:00
- **URL testée** : https://httpbin.org/forms/post
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-49-00_EQUIPE_3_FORMS_httpbin.org_forms_post.png` (1181.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-49-00_EQUIPE_3_FORMS_httpbin.org_forms_post.png â€” 1209821 octets

2026-10-26T11:49:00.333523Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:49:00.888057Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=554
2026-10-26T11:49:00.888667Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=555
2026-10-26T11:49:00.890963Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=557
2026-10-26T11:49:00.897717Z  INFO explorer_core::session::apply: apply: cascade ms=6
2026-10-26T11:49:00.899205Z  INFO explorer_core::session::apply: apply: boxtree ms=8
2026-10-26T11:49:00.933578Z  INFO explorer_core::session::apply: apply: layout ms=42
2026-10-26T11:49:00.954657Z  INFO explorer_core::session::apply: apply: repaint ms=63
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #19 — `https://html.duckduckgo.com/html/`
- **Horodatage** : 2026-10-26 12:50:50
- **URL testée** : https://html.duckduckgo.com/html/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-50-50_EQUIPE_3_FORMS_html.duckduckgo.com_html_.png` (2274.8 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-50-50_EQUIPE_3_FORMS_html.duckduckgo.com_html_.png â€” 2329366 octets

2026-10-26T11:50:50.178484Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:50:50.408523Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=230
2026-10-26T11:50:50.409106Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=230
2026-10-26T11:50:51.854320Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1675
2026-10-26T11:50:51.904893Z  INFO explorer_core::session::apply: apply: cascade ms=50
2026-10-26T11:50:52.009334Z  INFO explorer_core::session::apply: apply: boxtree ms=154
2026-10-26T11:50:52.018852Z  INFO explorer_core::session::apply: apply: layout ms=164
2026-10-26T11:50:52.222090Z  INFO explorer_core::session::apply: apply: repaint ms=367
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #20 — `https://lobste.rs/login`
- **Horodatage** : 2026-10-26 12:51:45
- **URL testée** : https://lobste.rs/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-51-45_EQUIPE_3_FORMS_lobste.rs_login.png` (1215.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-51-45_EQUIPE_3_FORMS_lobste.rs_login.png â€” 1244217 octets

2026-10-26T11:51:45.637495Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:51:46.111572Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=474
2026-10-26T11:51:46.112386Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=474
2026-10-26T11:51:46.751654Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1114
2026-10-26T11:51:46.795337Z  INFO explorer_core::session::apply: apply: cascade ms=41
2026-10-26T11:51:46.798565Z  INFO explorer_core::session::apply: apply: boxtree ms=44
2026-10-26T11:51:46.862724Z  INFO explorer_core::session::apply: apply: layout ms=109
2026-10-26T11:51:46.913108Z  INFO explorer_core::session::apply: apply: repaint ms=159
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #21 — `https://books.toscrape.com/`
- **Horodatage** : 2026-10-26 12:52:30
- **URL testée** : https://books.toscrape.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-52-30_EQUIPE_3_FORMS_books.toscrape.com_.png` (6782.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-52-30_EQUIPE_3_FORMS_books.toscrape.com_.png â€” 6945488 octets

2026-10-26T11:52:30.635598Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:52:31.301816Z  INFO explorer_core::session::apply: apply: cascade ms=17
2026-10-26T11:52:31.312173Z  INFO explorer_core::session::apply: apply: boxtree ms=27
2026-10-26T11:52:31.440436Z  INFO explorer_core::session::apply: apply: layout ms=155
2026-10-26T11:52:31.524758Z  INFO explorer_core::session::apply: apply: repaint ms=240
2026-10-26T11:52:31.537920Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=902
2026-10-26T11:52:31.543850Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=908
2026-10-26T11:52:33.128271Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2492
2026-10-26T11:52:33.129119Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=102
2026-10-26T11:52:33.129672Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:33.129711Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31819
2026-10-26T11:52:33.164393Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=34 ok=false
2026-10-26T11:52:33.166161Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=13966
2026-10-26T11:52:33.169545Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=false
2026-10-26T11:52:33.170696Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=55328
2026-10-26T11:52:33.217993Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=47 ok=false
2026-10-26T11:52:33.222587Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31995
2026-10-26T11:52:33.231613Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=9 ok=false
2026-10-26T11:52:33.234053Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=124
2026-10-26T11:52:33.234218Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:52:33.802106Z  INFO explorer_core::session::apply: apply: cascade ms=380
2026-10-26T11:52:33.840309Z  INFO explorer_core::session::apply: apply: boxtree ms=418
2026-10-26T11:52:34.117817Z  INFO explorer_core::session::apply: apply: layout ms=696
2026-10-26T11:52:34.477754Z  INFO explorer_core::session::apply: apply: repaint ms=1055
2026-10-26T11:52:35.222148Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:52:36.016441Z  INFO explorer_core::session::apply: apply: cascade ms=385
2026-10-26T11:52:36.054482Z  INFO explorer_core::session::apply: apply: boxtree ms=423
2026-10-26T11:52:36.143466Z  INFO explorer_core::session::apply: apply: layout ms=512
2026-10-26T11:52:36.465286Z  INFO explorer_core::session::apply: apply: repaint ms=834
2026-10-26T11:52:36.498484Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1276
[journal : 0 appliquÃ©s / 0 replis / 27 classÃ©es]
```

---

### ✈️ Vol #22 — `https://quotes.toscrape.com/login`
- **Horodatage** : 2026-10-26 12:53:13
- **URL testée** : https://quotes.toscrape.com/login
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-53-13_EQUIPE_3_FORMS_quotes.toscrape.com_login.png` (1364.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-53-13_EQUIPE_3_FORMS_quotes.toscrape.com_login.png â€” 1396706 octets

2026-10-26T11:53:13.179789Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:53:13.682937Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=503
2026-10-26T11:53:13.683479Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=503
2026-10-26T11:53:14.535348Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1355
2026-10-26T11:53:14.606147Z  INFO explorer_core::session::apply: apply: cascade ms=70
2026-10-26T11:53:14.607816Z  INFO explorer_core::session::apply: apply: boxtree ms=71
2026-10-26T11:53:14.636775Z  INFO explorer_core::session::apply: apply: layout ms=100
2026-10-26T11:53:14.670589Z  INFO explorer_core::session::apply: apply: repaint ms=134
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```
