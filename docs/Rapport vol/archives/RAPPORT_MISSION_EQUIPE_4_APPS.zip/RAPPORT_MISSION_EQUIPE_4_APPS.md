# 🛰️ RAPPORT DE MISSION EN VOL : ÉQUIPE 4 : APPLICATIONS RICHES, CANVAS & LAYOUTS (SITES INÉDITS)

*Rapport d'exploration inédit (100% nouveaux sites). Aucun ancien site validé.*

## 📋 Tableau Récapitulatif Chronologique

| N° | Horodatage | Site internet inédit | Statut | Poids Frame | Constat / Mur détecté |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 12:43:35 | `https://motherfuckingwebsite.com/` | **🟢 OK** | 2158.3 Ko | Rendu nominal réussi |
| 2 | 2026-10-26 12:44:07 | `https://bettermotherfuckingwebsite.com/` | **🔴 FAIL** | 0.0 Ko | erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com |
| 11 | 2026-10-26 12:44:31 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal réussi |
| 3 | 2026-10-26 12:44:57 | `https://jgthms.com/web-design-in-4-minutes/` | **🟢 OK** | 1180.6 Ko | Rendu nominal réussi |
| 12 | 2026-10-26 12:45:03 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal réussi |
| 4 | 2026-10-26 12:45:32 | `https://danluu.com/` | **🟢 OK** | 11293.3 Ko | Rendu nominal réussi |
| 13 | 2026-10-26 12:45:45 | `https://motherfuckingwebsite.com/` | **🟢 OK** | 2158.3 Ko | Rendu nominal réussi |
| 14 | 2026-10-26 12:46:11 | `https://bettermotherfuckingwebsite.com/` | **🔴 FAIL** | 0.0 Ko | erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com |
| 15 | 2026-10-26 12:46:56 | `https://jgthms.com/web-design-in-4-minutes/` | **🟢 OK** | 1180.6 Ko | Rendu nominal réussi |
| 16 | 2026-10-26 12:47:38 | `https://danluu.com/` | **🟢 OK** | 11293.3 Ko | Rendu nominal réussi |
| 17 | 2026-10-26 12:48:20 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal réussi |
| 5 | 2026-10-26 12:48:47 | `https://css-tricks.com/` | **🔴 FAIL** | 0.0 Ko | Rendu nominal réussi |
| 18 | 2026-10-26 12:49:04 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal réussi |
| 19 | 2026-10-26 12:50:55 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal réussi |
| 20 | 2026-10-26 12:51:50 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal réussi |
| 21 | 2026-10-26 12:52:40 | `https://motherfuckingwebsite.com/` | **🟢 OK** | 2158.3 Ko | Rendu nominal réussi |
| 22 | 2026-10-26 12:53:18 | `https://bettermotherfuckingwebsite.com/` | **🔴 FAIL** | 0.0 Ko | erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com |


## 🔍 Fiches Détaillées par Vol

---

### ✈️ Vol #1 — `https://motherfuckingwebsite.com/`
- **Horodatage** : 2026-10-26 12:43:35
- **URL testée (Inédite)** : https://motherfuckingwebsite.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-35_EQUIPE_4_APPS_motherfuckingwebsite.com_.png` (2158.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-35_EQUIPE_4_APPS_motherfuckingwebsite.com_.png — 2210064 octets

2026-10-26T11:43:35.661578Z  INFO explorer_core::session::navigate: nav: fetch+parse… tab=1
2026-10-26T11:43:36.135747Z  INFO explorer_core::session::navigate: nav: fetch+parse ok → peinture tab=1 ms=474
2026-10-26T11:43:36.136343Z  INFO explorer_core::session::navigate: nav: peinture ok → sous-ressources tab=1 ms=474
2026-10-26T11:43:36.138540Z  INFO explorer_core::session::navigate: nav: sous-ressources ok → commit tab=1 ms=476
2026-10-26T11:43:36.138637Z  INFO explorer_core::session::js_glue: script: eval… tab=1 bytes=442
2026-10-26T11:43:36.140506Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:43:36.147806Z  INFO explorer_core::session::apply: apply: cascade ms=4
2026-10-26T11:43:36.148864Z  INFO explorer_core::session::apply: apply: boxtree ms=5
2026-10-26T11:43:36.482735Z  INFO explorer_core::session::apply: apply: layout ms=339
2026-10-26T11:43:36.563698Z  INFO explorer_core::session::apply: apply: repaint ms=420
[journal : 0 appliqués / 0 replis / 0 classées]
```

---

### ✈️ Vol #2 — `https://bettermotherfuckingwebsite.com/`
- **Horodatage** : 2026-10-26 12:44:07
- **URL testée (Inédite)** : https://bettermotherfuckingwebsite.com/
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-44-07_EQUIPE_4_APPS_bettermotherfuckingwebsite.com_.png` (0.0 Ko)
- **Constat technique** : erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:44:07.468222Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:17.487518Z  INFO explorer_core::session::apply: apply: cascade ms=2
2026-10-26T11:44:17.487798Z  INFO explorer_core::session::apply: apply: boxtree ms=3
2026-10-26T11:44:17.533131Z  INFO explorer_core::session::apply: apply: layout ms=48
2026-10-26T11:44:17.562385Z  INFO explorer_core::session::apply: apply: repaint ms=77
erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com
```

---

### ✈️ Vol #11 — `https://w3c.github.io/`
- **Horodatage** : 2026-10-26 12:44:31
- **URL testée** : https://w3c.github.io/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-31_EQUIPE_4_APPS_w3c.github.io_.png` (6485.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-31_EQUIPE_4_APPS_w3c.github.io_.png â€” 6640947 octets

2026-10-26T11:44:31.868962Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:32.074325Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=205
2026-10-26T11:44:32.074629Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=205
2026-10-26T11:44:32.076801Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=207
2026-10-26T11:44:32.080129Z  INFO explorer_core::session::apply: apply: cascade ms=2
2026-10-26T11:44:32.080311Z  INFO explorer_core::session::apply: apply: boxtree ms=2
2026-10-26T11:44:32.087868Z  INFO explorer_core::session::apply: apply: layout ms=10
2026-10-26T11:44:32.100704Z  INFO explorer_core::session::apply: apply: repaint ms=23
2026-10-26T11:44:32.103228Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:32.320671Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=217
2026-10-26T11:44:32.323767Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=220
2026-10-26T11:44:33.701334Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1598
2026-10-26T11:44:33.701840Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=6042
2026-10-26T11:44:33.709707Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=7 ok=true
2026-10-26T11:44:33.709752Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=811
2026-10-26T11:44:33.712319Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:44:34.315736Z  INFO explorer_core::session::apply: apply: cascade ms=337
2026-10-26T11:44:34.328350Z  INFO explorer_core::session::apply: apply: boxtree ms=350
2026-10-26T11:44:34.898307Z  INFO explorer_core::session::apply: apply: layout ms=920
2026-10-26T11:44:35.581469Z  INFO explorer_core::session::apply: apply: repaint ms=1603
2026-10-26T11:44:35.652843Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:44:35.652926Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:44:35.662636Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:44:36.009533Z  INFO explorer_core::session::apply: apply: cascade ms=334
2026-10-26T11:44:36.022912Z  INFO explorer_core::session::apply: apply: boxtree ms=347
2026-10-26T11:44:36.067935Z  INFO explorer_core::session::apply: apply: layout ms=392
2026-10-26T11:44:36.714799Z  INFO explorer_core::session::apply: apply: repaint ms=1039
2026-10-26T11:44:36.726329Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1063
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #3 — `https://jgthms.com/web-design-in-4-minutes/`
- **Horodatage** : 2026-10-26 12:44:57
- **URL testée (Inédite)** : https://jgthms.com/web-design-in-4-minutes/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-57_EQUIPE_4_APPS_jgthms.com_web-design-in-4-minutes_.png` (1180.6 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-57_EQUIPE_4_APPS_jgthms.com_web-design-in-4-minutes_.png â€” 1208980 octets

2026-10-26T11:44:57.375177Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:57.685751Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=310
2026-10-26T11:44:57.688861Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=313
2026-10-26T11:44:57.953897Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=578
2026-10-26T11:44:57.954450Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1198
2026-10-26T11:44:57.961465Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=7 ok=false
2026-10-26T11:44:58.099960Z  INFO explorer_core::session::apply: apply: cascade ms=29
2026-10-26T11:44:58.608706Z  INFO explorer_core::session::apply: apply: boxtree ms=537
2026-10-26T11:44:58.668868Z  INFO explorer_core::session::apply: apply: layout ms=597
2026-10-26T11:44:58.699708Z  INFO explorer_core::session::apply: apply: repaint ms=628
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #12 — `https://stallman.org/`
- **Horodatage** : 2026-10-26 12:45:03
- **URL testée** : https://stallman.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-03_EQUIPE_4_APPS_stallman.org_.png` (25967.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-03_EQUIPE_4_APPS_stallman.org_.png â€” 26590344 octets

2026-10-26T11:45:04.154320Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:04.518443Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=364
2026-10-26T11:45:04.530027Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=375
2026-10-26T11:45:05.651704Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1497
2026-10-26T11:45:08.443385Z  INFO explorer_core::session::apply: apply: cascade ms=86
2026-10-26T11:45:08.480191Z  INFO explorer_core::session::apply: apply: boxtree ms=123
2026-10-26T11:45:10.917617Z  INFO explorer_core::session::apply: apply: layout ms=2560
2026-10-26T11:45:11.734644Z  INFO explorer_core::session::apply: apply: repaint ms=3377
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #4 — `https://danluu.com/`
- **Horodatage** : 2026-10-26 12:45:32
- **URL testée (Inédite)** : https://danluu.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-32_EQUIPE_4_APPS_danluu.com_.png` (11293.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-32_EQUIPE_4_APPS_danluu.com_.png â€” 11564342 octets

2026-10-26T11:45:32.316700Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:32.464774Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=148
2026-10-26T11:45:32.468454Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=151
2026-10-26T11:45:32.580693Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=264
2026-10-26T11:45:32.581358Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31853
2026-10-26T11:45:32.638800Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=57 ok=true
2026-10-26T11:45:32.682933Z  INFO explorer_core::session::apply: apply: cascade ms=43
2026-10-26T11:45:32.699161Z  INFO explorer_core::session::apply: apply: boxtree ms=59
2026-10-26T11:45:33.669271Z  INFO explorer_core::session::apply: apply: layout ms=1029
2026-10-26T11:45:33.873433Z  INFO explorer_core::session::apply: apply: repaint ms=1233
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #13 — `https://motherfuckingwebsite.com/`
- **Horodatage** : 2026-10-26 12:45:45
- **URL testée** : https://motherfuckingwebsite.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-45_EQUIPE_4_APPS_motherfuckingwebsite.com_.png` (2158.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-45_EQUIPE_4_APPS_motherfuckingwebsite.com_.png â€” 2210064 octets

2026-10-26T11:45:45.875694Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:46.346476Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=470
2026-10-26T11:45:46.347078Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=471
2026-10-26T11:45:46.349121Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=473
2026-10-26T11:45:46.349224Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=442
2026-10-26T11:45:46.350946Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:45:46.358290Z  INFO explorer_core::session::apply: apply: cascade ms=4
2026-10-26T11:45:46.359393Z  INFO explorer_core::session::apply: apply: boxtree ms=5
2026-10-26T11:45:46.696321Z  INFO explorer_core::session::apply: apply: layout ms=342
2026-10-26T11:45:46.775829Z  INFO explorer_core::session::apply: apply: repaint ms=422
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #14 — `https://bettermotherfuckingwebsite.com/`
- **Horodatage** : 2026-10-26 12:46:11
- **URL testée** : https://bettermotherfuckingwebsite.com/
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-46-11_EQUIPE_4_APPS_bettermotherfuckingwebsite.com_.png` (0.0 Ko)
- **Constat technique** : erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:46:11.437935Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:21.449647Z  INFO explorer_core::session::apply: apply: cascade ms=2
2026-10-26T11:46:21.449940Z  INFO explorer_core::session::apply: apply: boxtree ms=3
2026-10-26T11:46:21.495892Z  INFO explorer_core::session::apply: apply: layout ms=49
2026-10-26T11:46:21.523482Z  INFO explorer_core::session::apply: apply: repaint ms=76
erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com
```

---

### ✈️ Vol #15 — `https://jgthms.com/web-design-in-4-minutes/`
- **Horodatage** : 2026-10-26 12:46:56
- **URL testée** : https://jgthms.com/web-design-in-4-minutes/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-46-56_EQUIPE_4_APPS_jgthms.com_web-design-in-4-minutes_.png` (1180.6 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-46-56_EQUIPE_4_APPS_jgthms.com_web-design-in-4-minutes_.png â€” 1208980 octets

2026-10-26T11:46:57.074962Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:57.405815Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=330
2026-10-26T11:46:57.408880Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=333
2026-10-26T11:46:57.706055Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=631
2026-10-26T11:46:57.706579Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1198
2026-10-26T11:46:57.713005Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=false
2026-10-26T11:46:57.848731Z  INFO explorer_core::session::apply: apply: cascade ms=27
2026-10-26T11:46:58.362591Z  INFO explorer_core::session::apply: apply: boxtree ms=541
2026-10-26T11:46:58.422418Z  INFO explorer_core::session::apply: apply: layout ms=601
2026-10-26T11:46:58.452816Z  INFO explorer_core::session::apply: apply: repaint ms=631
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #16 — `https://danluu.com/`
- **Horodatage** : 2026-10-26 12:47:38
- **URL testée** : https://danluu.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-47-38_EQUIPE_4_APPS_danluu.com_.png` (11293.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-47-38_EQUIPE_4_APPS_danluu.com_.png â€” 11564342 octets

2026-10-26T11:47:38.449141Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:47:38.597335Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=148
2026-10-26T11:47:38.601010Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=151
2026-10-26T11:47:38.707181Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=258
2026-10-26T11:47:38.707810Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31853
2026-10-26T11:47:38.764822Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=57 ok=true
2026-10-26T11:47:38.809340Z  INFO explorer_core::session::apply: apply: cascade ms=43
2026-10-26T11:47:38.825998Z  INFO explorer_core::session::apply: apply: boxtree ms=60
2026-10-26T11:47:39.814088Z  INFO explorer_core::session::apply: apply: layout ms=1048
2026-10-26T11:47:40.024794Z  INFO explorer_core::session::apply: apply: repaint ms=1259
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #17 — `https://2048game.com/`
- **Horodatage** : 2026-10-26 12:48:20
- **URL testée** : https://2048game.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-48-20_EQUIPE_4_APPS_2048game.com_.png` (3488.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-48-20_EQUIPE_4_APPS_2048game.com_.png â€” 3571697 octets

2026-10-26T11:48:20.269891Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:48:20.395761Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=125
2026-10-26T11:48:20.397394Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=127
2026-10-26T11:48:20.604228Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=334
2026-10-26T11:48:20.604537Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=12332
2026-10-26T11:48:20.657670Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=53 ok=true
2026-10-26T11:48:20.876914Z  INFO explorer_core::session::apply: apply: cascade ms=212
2026-10-26T11:48:20.884429Z  INFO explorer_core::session::apply: apply: boxtree ms=220
2026-10-26T11:48:21.170282Z  INFO explorer_core::session::apply: apply: layout ms=506
2026-10-26T11:48:21.313319Z  INFO explorer_core::session::apply: apply: repaint ms=649
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #5 — `https://css-tricks.com/`
- **Horodatage** : 2026-10-26 12:48:47
- **URL testée (Inédite)** : https://css-tricks.com/
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-48-47_EQUIPE_4_APPS_css-tricks.com_.png` (0.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:48:47.620970Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:48:47.943230Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=322
2026-10-26T11:48:47.954574Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=333
```

---

### ✈️ Vol #18 — `https://github.com/`
- **Horodatage** : 2026-10-26 12:49:04
- **URL testée** : https://github.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-49-04_EQUIPE_4_APPS_github.com_.png` (2910.4 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-49-04_EQUIPE_4_APPS_github.com_.png â€” 2980216 octets

2026-10-26T11:49:04.554598Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:49:04.832700Z  INFO explorer_core::session::apply: apply: cascade ms=52
2026-10-26T11:49:04.891620Z  INFO explorer_core::session::apply: apply: boxtree ms=111
2026-10-26T11:49:05.064973Z  INFO explorer_core::session::apply: apply: layout ms=285
2026-10-26T11:49:05.154900Z  INFO explorer_core::session::apply: apply: repaint ms=375
2026-10-26T11:49:05.280111Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=725
2026-10-26T11:49:05.294388Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=739
2026-10-26T11:49:15.693432Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=11138
2026-10-26T11:49:15.952055Z DEBUG explorer_jscore::dom_host: customElements.define name=live-region-9e3d04d4-4ffa-42e7-bc00-c8338d57d684
2026-10-26T11:49:16.176330Z DEBUG explorer_jscore::dom_host: customElements.define name=include-fragment
2026-10-26T11:49:16.176945Z DEBUG explorer_jscore::dom_host: customElements.define name=remote-input
2026-10-26T11:49:16.178770Z DEBUG explorer_jscore::dom_host: customElements.define name=action-list
2026-10-26T11:49:16.182893Z DEBUG explorer_jscore::dom_host: customElements.define name=action-bar
2026-10-26T11:49:16.183851Z DEBUG explorer_jscore::dom_host: customElements.define name=details-menu
2026-10-26T11:49:16.184387Z DEBUG explorer_jscore::dom_host: customElements.define name=anchored-position
2026-10-26T11:49:16.184835Z DEBUG explorer_jscore::dom_host: customElements.define name=dialog-helper
2026-10-26T11:49:16.192154Z DEBUG explorer_jscore::dom_host: customElements.define name=focus-group
2026-10-26T11:49:16.193279Z DEBUG explorer_jscore::dom_host: customElements.define name=scrollable-region
2026-10-26T11:49:16.197551Z DEBUG explorer_jscore::dom_host: customElements.define name=modal-dialog
2026-10-26T11:49:16.198919Z DEBUG explorer_jscore::dom_host: customElements.define name=nav-list
2026-10-26T11:49:16.200218Z DEBUG explorer_jscore::dom_host: customElements.define name=nav-list-group
2026-10-26T11:49:16.201606Z DEBUG explorer_jscore::dom_host: customElements.define name=segmented-control
2026-10-26T11:49:16.203297Z DEBUG explorer_jscore::dom_host: customElements.define name=toggle-switch
2026-10-26T11:49:16.205731Z DEBUG explorer_jscore::dom_host: customElements.define name=tool-tip
2026-10-26T11:49:16.210703Z DEBUG explorer_jscore::dom_host: customElements.define name=x-banner
2026-10-26T11:49:16.211815Z DEBUG explorer_jscore::dom_host: customElements.define name=auto-complete
2026-10-26T11:49:16.212506Z DEBUG explorer_jscore::dom_host: customElements.define name=clipboard-copy
2026-10-26T11:49:16.219021Z DEBUG explorer_jscore::dom_host: customElements.define name=relative-time
2026-10-26T11:49:16.219644Z DEBUG explorer_jscore::dom_host: customElements.define name=tab-container
2026-10-26T11:49:16.220734Z DEBUG explorer_jscore::dom_host: customElements.define name=primer-multi-input
2026-10-26T11:49:16.221628Z DEBUG explorer_jscore::dom_host: customElements.define name=auto-check
2026-10-26T11:49:16.224083Z DEBUG explorer_jscore::dom_host: customElements.define name=primer-text-field
2026-10-26T11:49:16.225530Z DEBUG explorer_jscore::dom_host: customElements.define name=primer-text-area
2026-10-26T11:49:16.226754Z DEBUG explorer_jscore::dom_host: customElements.define name=toggle-switch-input
2026-10-26T11:49:16.228286Z DEBUG explorer_jscore::dom_host: customElements.define name=action-menu
2026-10-26T11:49:16.229516Z DEBUG explorer_jscore::dom_host: customElements.define name=live-region
2026-10-26T11:49:16.232558Z DEBUG explorer_jscore::dom_host: customElements.define name=select-panel
2026-10-26T11:49:16.233922Z DEBUG explorer_jscore::dom_host: customElements.define name=details-toggle
2026-10-26T11:49:16.235321Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view
2026-10-26T11:49:16.236557Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view-icon-pair
2026-10-26T11:49:16.239458Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view-sub-tree-node
2026-10-26T11:49:16.240272Z DEBUG explorer_jscore::dom_host: customElements.define name=tree-view-include-fragment
2026-10-26T11:49:16.241138Z DEBUG explorer_jscore::dom_host: customElements.define name=details-dialog
2026-10-26T11:49:16.243936Z DEBUG explorer_jscore::dom_host: customElements.define name=file-attachment
2026-10-26T11:49:16.244667Z DEBUG explorer_jscore::dom_host: customElements.define name=filter-input
2026-10-26T11:49:16.255548Z DEBUG explorer_jscore::dom_host: customElements.define name=g-emoji
2026-10-26T11:49:16.256657Z DEBUG explorer_jscore::dom_host: customElements.define name=md-header
2026-10-26T11:49:16.257064Z DEBUG explorer_jscore::dom_host: customElements.define name=md-bold
2026-10-26T11:49:16.257467Z DEBUG explorer_jscore::dom_host: customElements.define name=md-italic
2026-10-26T11:49:16.257864Z DEBUG explorer_jscore::dom_host: customElements.define name=md-quote
2026-10-26T11:49:16.258260Z DEBUG explorer_jscore::dom_host: customElements.define name=md-code
2026-10-26T11:49:16.258654Z DEBUG explorer_jscore::dom_host: customElements.define name=md-link
2026-10-26T11:49:16.259045Z DEBUG explorer_jscore::dom_host: customElements.define name=md-image
2026-10-26T11:49:16.259436Z DEBUG explorer_jscore::dom_host: customElements.define name=md-unordered-list
2026-10-26T11:49:16.259834Z DEBUG explorer_jscore::dom_host: customElements.define name=md-ordered-list
2026-10-26T11:49:16.260228Z DEBUG explorer_jscore::dom_host: customElements.define name=md-task-list
2026-10-26T11:49:16.260620Z DEBUG explorer_jscore::dom_host: customElements.define name=md-mention
2026-10-26T11:49:16.261012Z DEBUG explorer_jscore::dom_host: customElements.define name=md-ref
2026-10-26T11:49:16.261420Z DEBUG explorer_jscore::dom_host: customElements.define name=md-strikethrough
2026-10-26T11:49:16.261852Z DEBUG explorer_jscore::dom_host: customElements.define name=markdown-toolbar
2026-10-26T11:49:16.262923Z DEBUG explorer_jscore::dom_host: customElements.define name=task-lists
2026-10-26T11:49:16.267533Z DEBUG explorer_jscore::dom_host: customElements.define name=text-expander
2026-10-26T11:49:16.268175Z DEBUG explorer_jscore::dom_host: customElements.define name=typing-effect
2026-10-26T11:49:16.268767Z DEBUG explorer_jscore::dom_host: customElements.define name=image-crop
2026-10-26T11:49:17.229323Z DEBUG explorer_jscore::dom_host: customElements.define name=batch-deferred-content
2026-10-26T11:49:17.581670Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-frame
2026-10-26T11:49:17.582174Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-stream
2026-10-26T11:49:17.582545Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-stream-source
2026-10-26T11:49:17.624095Z DEBUG explorer_jscore::dom_host: customElements.define name=webauthn-get
2026-10-26T11:49:17.636326Z DEBUG explorer_jscore::dom_host: customElements.define name=sudo-credential-options
2026-10-26T11:49:17.781071Z DEBUG explorer_jscore::dom_host: customElements.define name=collapsible-sidebar-widget
2026-10-26T11:49:17.783588Z DEBUG explorer_jscore::dom_host: customElements.define name=sidebar-memex-input
2026-10-26T11:49:17.811105Z DEBUG explorer_jscore::module: import() dynamique spec="./4f-128d9b1a702b1593.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:49:17.836690Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-l1-18d79a71714bc7ea.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:49:21.156872Z DEBUG explorer_jscore::dom_host: customElements.define name=react-app
2026-10-26T11:49:54.209395Z  INFO explorer_core::session::apply: apply: cascade ms=5494
2026-10-26T11:49:55.047299Z  INFO explorer_core::session::apply: apply: boxtree ms=6332
2026-10-26T11:49:56.234739Z  INFO explorer_core::session::apply: apply: layout ms=7519
2026-10-26T11:49:59.769758Z  INFO explorer_core::session::apply: apply: repaint ms=11054
2026-10-26T11:49:59.926638Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-select-panel-1db988c3b2debb9f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:49:59.951281Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-toggle-switch-d84c21582809dda9.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:49:59.982169Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-cookie-consent-link-f9fd1ccb00a8c36f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.023349Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-dg-9bfcf8075100cf89.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.048231Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-fullstory-capture-15d50c217bc93073.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.073212Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-ghcc-consent-47aaf7da7816fc53.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.097908Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-element-webauthn-get-594ac3b363fd9c1e.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.164327Z DEBUG explorer_jscore::module: import() dynamique spec="./g6m-c6c2e85d4cbe6e0f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.200264Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-app-install-banner-partial-ed58f1b49a2d8d01.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.244194Z DEBUG explorer_jscore::module: import() dynamique spec="./gw-4bf343b417f9ec19.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.281165Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-keyboard-shortcuts-dialog-6d857a36d55539c5.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.319262Z DEBUG explorer_jscore::module: import() dynamique spec="./hiz-0c55010ddab90e83.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.335223Z DEBUG explorer_jscore::module: import() dynamique spec="./e2-0b5115974c072a51.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.372783Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-marketing-footer-7d6fb2ccc544828f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.385214Z DEBUG explorer_jscore::module: import() dynamique spec="./ff-d6dad91563c22a66.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.421770Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-marketing-global-banner-b959d69baa329334.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.440705Z DEBUG explorer_jscore::module: import() dynamique spec="./skl-90fea02d318d647f.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.450518Z DEBUG explorer_jscore::module: import() dynamique spec="./z7-54a4e2eade1aa26b.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.469955Z DEBUG explorer_jscore::module: import() dynamique spec="./a6j-32ec4660665b36c1.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.495336Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-lazy-react-partial-marketing-header-b4346dea7b2f491a.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.520831Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-xvz-afdb8ae9dfb2e6cb.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:00.546208Z DEBUG explorer_jscore::module: import() dynamique spec="./chunk-bl-16891fdfed025b0e.js" referrer="https://github.githubassets.com/assets/wp-runtime-baeadb73d0a8471b.js"
2026-10-26T11:50:02.902959Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:50:17.437945Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=14534
[journal : 0 appliquÃ©s / 0 replis / 6 classÃ©es]
```

---

### ✈️ Vol #19 — `https://w3c.github.io/`
- **Horodatage** : 2026-10-26 12:50:55
- **URL testée** : https://w3c.github.io/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-50-55_EQUIPE_4_APPS_w3c.github.io_.png` (6485.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-50-55_EQUIPE_4_APPS_w3c.github.io_.png â€” 6640947 octets

2026-10-26T11:50:55.700105Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:50:55.785624Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=85
2026-10-26T11:50:55.786094Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=86
2026-10-26T11:50:55.788462Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=88
2026-10-26T11:50:55.792611Z  INFO explorer_core::session::apply: apply: cascade ms=2
2026-10-26T11:50:55.792873Z  INFO explorer_core::session::apply: apply: boxtree ms=2
2026-10-26T11:50:55.800576Z  INFO explorer_core::session::apply: apply: layout ms=10
2026-10-26T11:50:55.813224Z  INFO explorer_core::session::apply: apply: repaint ms=23
2026-10-26T11:50:55.815742Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:50:56.051598Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=235
2026-10-26T11:50:56.054749Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=239
2026-10-26T11:50:57.349884Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1534
2026-10-26T11:50:57.350390Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=6042
2026-10-26T11:50:57.358781Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=8 ok=true
2026-10-26T11:50:57.358819Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=811
2026-10-26T11:50:57.361586Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:50:57.996108Z  INFO explorer_core::session::apply: apply: cascade ms=366
2026-10-26T11:50:58.008486Z  INFO explorer_core::session::apply: apply: boxtree ms=378
2026-10-26T11:50:58.591001Z  INFO explorer_core::session::apply: apply: layout ms=961
2026-10-26T11:50:59.281451Z  INFO explorer_core::session::apply: apply: repaint ms=1651
2026-10-26T11:50:59.354194Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:50:59.354293Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:50:59.363749Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:50:59.710657Z  INFO explorer_core::session::apply: apply: cascade ms=334
2026-10-26T11:50:59.723955Z  INFO explorer_core::session::apply: apply: boxtree ms=347
2026-10-26T11:50:59.767938Z  INFO explorer_core::session::apply: apply: layout ms=391
2026-10-26T11:51:00.401059Z  INFO explorer_core::session::apply: apply: repaint ms=1024
2026-10-26T11:51:00.412104Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1048
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #20 — `https://stallman.org/`
- **Horodatage** : 2026-10-26 12:51:50
- **URL testée** : https://stallman.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-51-50_EQUIPE_4_APPS_stallman.org_.png` (25967.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-51-50_EQUIPE_4_APPS_stallman.org_.png â€” 26590344 octets

2026-10-26T11:51:50.613890Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:51:50.866026Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=252
2026-10-26T11:51:50.877409Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=263
2026-10-26T11:51:51.395977Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=782
2026-10-26T11:51:54.121721Z  INFO explorer_core::session::apply: apply: cascade ms=86
2026-10-26T11:51:54.158320Z  INFO explorer_core::session::apply: apply: boxtree ms=123
2026-10-26T11:51:56.608752Z  INFO explorer_core::session::apply: apply: layout ms=2573
2026-10-26T11:51:57.424256Z  INFO explorer_core::session::apply: apply: repaint ms=3388
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #21 — `https://motherfuckingwebsite.com/`
- **Horodatage** : 2026-10-26 12:52:40
- **URL testée** : https://motherfuckingwebsite.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-52-40_EQUIPE_4_APPS_motherfuckingwebsite.com_.png` (2158.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-52-40_EQUIPE_4_APPS_motherfuckingwebsite.com_.png â€” 2210064 octets

2026-10-26T11:52:40.435431Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:52:41.024003Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=588
2026-10-26T11:52:41.024626Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=589
2026-10-26T11:52:41.026837Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=591
2026-10-26T11:52:41.026938Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=442
2026-10-26T11:52:41.028706Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:52:41.035968Z  INFO explorer_core::session::apply: apply: cascade ms=4
2026-10-26T11:52:41.037022Z  INFO explorer_core::session::apply: apply: boxtree ms=5
2026-10-26T11:52:41.379906Z  INFO explorer_core::session::apply: apply: layout ms=348
2026-10-26T11:52:41.460144Z  INFO explorer_core::session::apply: apply: repaint ms=428
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #22 — `https://bettermotherfuckingwebsite.com/`
- **Horodatage** : 2026-10-26 12:53:18
- **URL testée** : https://bettermotherfuckingwebsite.com/
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-53-18_EQUIPE_4_APPS_bettermotherfuckingwebsite.com_.png` (0.0 Ko)
- **Constat technique** : erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:53:18.587641Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:53:28.601759Z  INFO explorer_core::session::apply: apply: cascade ms=2
2026-10-26T11:53:28.602042Z  INFO explorer_core::session::apply: apply: boxtree ms=3
2026-10-26T11:53:28.646222Z  INFO explorer_core::session::apply: apply: layout ms=47
2026-10-26T11:53:28.673760Z  INFO explorer_core::session::apply: apply: repaint ms=74
erreur : fetch : timeout connect aprÃ¨s 10000 ms vers https://bettermotherfuckingwebsite.com
```
