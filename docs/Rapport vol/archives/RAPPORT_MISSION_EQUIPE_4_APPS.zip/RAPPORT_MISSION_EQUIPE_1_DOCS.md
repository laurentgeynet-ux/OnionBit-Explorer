# 🛰️ RAPPORT DE MISSION EN VOL : ÉQUIPE 1 : DOCUMENTS, SAVOIR & RÉFÉRENCES (SITES INÉDITS)

*Rapport d'exploration inédit (100% nouveaux sites). Aucun ancien site validé.*

## 📋 Tableau Récapitulatif Chronologique

| N° | Horodatage | Site internet inédit | Statut | Poids Frame | Constat / Mur détecté |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 12:43:06 | `https://doc.rust-lang.org/book/` | **🟢 OK** | 1338.5 Ko | Rendu nominal réussi |
| 2 | 2026-10-26 12:43:42 | `https://docs.python.org/3/` | **🟢 OK** | 3570.6 Ko | Rendu nominal réussi |
| 11 | 2026-10-26 12:43:49 | `https://docs.python.org/3/` | **🟢 OK** | 3570.6 Ko | Rendu nominal réussi |
| 3 | 2026-10-26 12:44:22 | `https://www.gnu.org/` | **🟢 OK** | 7389.0 Ko | Rendu nominal réussi |
| 12 | 2026-10-26 12:44:45 | `https://lite.cnn.com/` | **🟢 OK** | 5381.8 Ko | Rendu nominal réussi |
| 4 | 2026-10-26 12:45:03 | `https://www.kernel.org/` | **🟢 OK** | 3139.8 Ko | Rendu nominal réussi |
| 13 | 2026-10-26 12:45:23 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal réussi |
| 5 | 2026-10-26 12:45:41 | `https://www.gutenberg.org/` | **🟢 OK** | 2188.0 Ko | Rendu nominal réussi |
| 14 | 2026-10-26 12:45:56 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal réussi |
| 15 | 2026-10-26 12:46:29 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal réussi |
| 16 | 2026-10-26 12:47:06 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal réussi |
| 17 | 2026-10-26 12:47:50 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal réussi |
| 18 | 2026-10-26 12:48:30 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal réussi |
| 19 | 2026-10-26 12:50:28 | `https://lobste.rs/` | **🟢 OK** | 5509.4 Ko | Rendu nominal réussi |
| 20 | 2026-10-26 12:51:09 | `https://www.w3.org/` | **🟢 OK** | 20495.5 Ko | Rendu nominal réussi |
| 21 | 2026-10-26 12:52:09 | `https://www.gnu.org/` | **🟢 OK** | 7389.0 Ko | Rendu nominal réussi |
| 22 | 2026-10-26 12:52:50 | `https://doc.rust-lang.org/book/` | **🟢 OK** | 1338.5 Ko | Rendu nominal réussi |


## 🔍 Fiches Détaillées par Vol

---

### ✈️ Vol #1 — `https://doc.rust-lang.org/book/`
- **Horodatage** : 2026-10-26 12:43:06
- **URL testée (Inédite)** : https://doc.rust-lang.org/book/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-06_EQUIPE_1_DOCS_doc.rust-lang.org_book_.png` (1338.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-06_EQUIPE_1_DOCS_doc.rust-lang.org_book_.png â€” 1370610 octets

2026-10-26T11:43:07.071472Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:07.231708Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=160
2026-10-26T11:43:07.233517Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=162
2026-10-26T11:43:11.651056Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=4579
2026-10-26T11:43:11.651400Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=213
2026-10-26T11:43:11.651794Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:11.651839Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=41494
2026-10-26T11:43:11.660291Z DEBUG explorer_jscore::dom_host: customElements.define name=mdbook-sidebar-scrollbox
2026-10-26T11:43:11.948691Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=296 ok=true
2026-10-26T11:43:11.948747Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=559
2026-10-26T11:43:11.949235Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:11.949253Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=500
2026-10-26T11:43:11.949616Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:11.949633Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=621
2026-10-26T11:43:11.950238Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:11.950255Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=469
2026-10-26T11:43:11.956664Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=true
2026-10-26T11:43:11.956687Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=56
2026-10-26T11:43:11.956818Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:11.956855Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=18051
2026-10-26T11:43:12.046592Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=89 ok=true
2026-10-26T11:43:12.046654Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=17320
2026-10-26T11:43:12.069123Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=22 ok=true
2026-10-26T11:43:12.069184Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=20294
2026-10-26T11:43:12.086670Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=17 ok=true
2026-10-26T11:43:12.086738Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=10754
2026-10-26T11:43:12.094895Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=8 ok=true
2026-10-26T11:43:12.094958Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=137537
2026-10-26T11:43:13.362872Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1267 ok=true
2026-10-26T11:43:13.362939Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=30932
2026-10-26T11:43:13.424668Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=61 ok=true
2026-10-26T11:43:13.424729Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2653
2026-10-26T11:43:13.425544Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:13.585037Z  INFO explorer_core::session::apply: apply: cascade ms=139
2026-10-26T11:43:13.944159Z  INFO explorer_core::session::apply: apply: boxtree ms=499
2026-10-26T11:43:14.104728Z  INFO explorer_core::session::apply: apply: layout ms=659
2026-10-26T11:43:14.354344Z  INFO explorer_core::session::apply: apply: repaint ms=909
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #2 — `https://docs.python.org/3/`
- **Horodatage** : 2026-10-26 12:43:42
- **URL testée (Inédite)** : https://docs.python.org/3/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-42_EQUIPE_1_DOCS_docs.python.org_3_.png` (3570.6 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-42_EQUIPE_1_DOCS_docs.python.org_3_.png â€” 3656289 octets

2026-10-26T11:43:43.135375Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:43.251205Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=115
2026-10-26T11:43:43.254539Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=119
2026-10-26T11:43:43.537531Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=402
2026-10-26T11:43:43.538104Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=330
2026-10-26T11:43:43.538501Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.538531Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4322
2026-10-26T11:43:43.540096Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:43:43.540165Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=5123
2026-10-26T11:43:43.545119Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=4 ok=true
2026-10-26T11:43:43.545191Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2395
2026-10-26T11:43:43.545784Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.545805Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3055
2026-10-26T11:43:43.546541Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.546589Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2137
2026-10-26T11:43:43.547166Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.547194Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=559
2026-10-26T11:43:43.547433Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.547452Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=779
2026-10-26T11:43:43.548283Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.548310Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2108
2026-10-26T11:43:43.549160Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:43.549180Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=8091
2026-10-26T11:43:43.551686Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=false
2026-10-26T11:43:43.552404Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3960
2026-10-26T11:43:43.558501Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=true
2026-10-26T11:43:43.712575Z  INFO explorer_core::session::apply: apply: cascade ms=136
2026-10-26T11:43:43.723974Z  INFO explorer_core::session::apply: apply: boxtree ms=147
2026-10-26T11:43:44.113617Z  INFO explorer_core::session::apply: apply: layout ms=537
2026-10-26T11:43:44.280630Z  INFO explorer_core::session::apply: apply: repaint ms=704
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #11 — `https://docs.python.org/3/`
- **Horodatage** : 2026-10-26 12:43:49
- **URL testée** : https://docs.python.org/3/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-49_EQUIPE_1_DOCS_docs.python.org_3_.png` (3570.6 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-49_EQUIPE_1_DOCS_docs.python.org_3_.png â€” 3656289 octets

2026-10-26T11:43:49.611606Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:49.704983Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=93
2026-10-26T11:43:49.708203Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=96
2026-10-26T11:43:49.896445Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=284
2026-10-26T11:43:49.897044Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=330
2026-10-26T11:43:49.897412Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.897445Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4322
2026-10-26T11:43:49.899017Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:43:49.899108Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=5123
2026-10-26T11:43:49.903898Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=4 ok=true
2026-10-26T11:43:49.903988Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2395
2026-10-26T11:43:49.904577Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.904598Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3055
2026-10-26T11:43:49.905329Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.905355Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2137
2026-10-26T11:43:49.905919Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.905941Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=559
2026-10-26T11:43:49.906182Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.906202Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=779
2026-10-26T11:43:49.907039Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.907078Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2108
2026-10-26T11:43:49.907884Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.907929Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=8091
2026-10-26T11:43:49.910267Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=false
2026-10-26T11:43:49.911038Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3960
2026-10-26T11:43:49.916399Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=5 ok=true
2026-10-26T11:43:50.072219Z  INFO explorer_core::session::apply: apply: cascade ms=137
2026-10-26T11:43:50.083832Z  INFO explorer_core::session::apply: apply: boxtree ms=149
2026-10-26T11:43:50.478197Z  INFO explorer_core::session::apply: apply: layout ms=543
2026-10-26T11:43:50.645364Z  INFO explorer_core::session::apply: apply: repaint ms=710
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #3 — `https://www.gnu.org/`
- **Horodatage** : 2026-10-26 12:44:22
- **URL testée (Inédite)** : https://www.gnu.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-22_EQUIPE_1_DOCS_www.gnu.org_.png` (7389.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-22_EQUIPE_1_DOCS_www.gnu.org_.png â€” 7566355 octets

2026-10-26T11:44:22.790621Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:23.284212Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=493
2026-10-26T11:44:23.287848Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=497
2026-10-26T11:44:24.733623Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1943
2026-10-26T11:44:25.898656Z  INFO explorer_core::session::apply: apply: cascade ms=130
2026-10-26T11:44:25.914322Z  INFO explorer_core::session::apply: apply: boxtree ms=145
2026-10-26T11:44:26.656478Z  INFO explorer_core::session::apply: apply: layout ms=887
2026-10-26T11:44:27.377890Z  INFO explorer_core::session::apply: apply: repaint ms=1609
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #12 — `https://lite.cnn.com/`
- **Horodatage** : 2026-10-26 12:44:45
- **URL testée** : https://lite.cnn.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-45_EQUIPE_1_DOCS_lite.cnn.com_.png` (5381.8 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-45_EQUIPE_1_DOCS_lite.cnn.com_.png â€” 5511007 octets

2026-10-26T11:44:45.954451Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:46.114824Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=160
2026-10-26T11:44:46.117448Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=163
2026-10-26T11:44:46.179669Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=225
2026-10-26T11:44:46.180103Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=44113
2026-10-26T11:44:46.191375Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=11 ok=true
2026-10-26T11:44:46.191429Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1325
2026-10-26T11:44:46.195887Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=4 ok=true
2026-10-26T11:44:46.273402Z  INFO explorer_core::session::apply: apply: cascade ms=76
2026-10-26T11:44:46.283202Z  INFO explorer_core::session::apply: apply: boxtree ms=86
2026-10-26T11:44:47.324319Z  INFO explorer_core::session::apply: apply: layout ms=1127
2026-10-26T11:44:49.230336Z  INFO explorer_core::session::apply: apply: repaint ms=3033
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #4 — `https://www.kernel.org/`
- **Horodatage** : 2026-10-26 12:45:03
- **URL testée (Inédite)** : https://www.kernel.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-03_EQUIPE_1_DOCS_www.kernel.org_.png` (3139.8 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-03_EQUIPE_1_DOCS_www.kernel.org_.png â€” 3215130 octets

2026-10-26T11:45:04.116830Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:04.228052Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=111
2026-10-26T11:45:04.231708Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=114
2026-10-26T11:45:04.455168Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=338
2026-10-26T11:45:04.504782Z  INFO explorer_core::session::apply: apply: cascade ms=38
2026-10-26T11:45:04.519839Z  INFO explorer_core::session::apply: apply: boxtree ms=53
2026-10-26T11:45:04.639933Z  INFO explorer_core::session::apply: apply: layout ms=173
2026-10-26T11:45:04.740662Z  INFO explorer_core::session::apply: apply: repaint ms=274
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #13 — `https://example.com/`
- **Horodatage** : 2026-10-26 12:45:23
- **URL testée** : https://example.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-23_EQUIPE_1_DOCS_example.com_.png` (1259.9 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-23_EQUIPE_1_DOCS_example.com_.png â€” 1290167 octets

2026-10-26T11:45:24.022137Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:24.174608Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=152
2026-10-26T11:45:24.174942Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=152
2026-10-26T11:45:24.251072Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=228
2026-10-26T11:45:24.251184Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1963
2026-10-26T11:45:24.252742Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:45:24.260396Z  INFO explorer_core::session::apply: apply: cascade ms=5
2026-10-26T11:45:24.263101Z  INFO explorer_core::session::apply: apply: boxtree ms=8
2026-10-26T11:45:24.546469Z  INFO explorer_core::session::apply: apply: layout ms=292
2026-10-26T11:45:24.605366Z  INFO explorer_core::session::apply: apply: repaint ms=350
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #5 — `https://www.gutenberg.org/`
- **Horodatage** : 2026-10-26 12:45:41
- **URL testée (Inédite)** : https://www.gutenberg.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-41_EQUIPE_1_DOCS_www.gutenberg.org_.png` (2188.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-41_EQUIPE_1_DOCS_www.gutenberg.org_.png â€” 2240531 octets

2026-10-26T11:45:41.177204Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:41.655058Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=477
2026-10-26T11:45:41.659430Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=482
2026-10-26T11:45:43.337782Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2160
2026-10-26T11:45:43.911543Z  INFO explorer_core::session::apply: apply: cascade ms=159
2026-10-26T11:45:43.950232Z  INFO explorer_core::session::apply: apply: boxtree ms=197
2026-10-26T11:45:44.496025Z  INFO explorer_core::session::apply: apply: layout ms=743
2026-10-26T11:45:44.607261Z  INFO explorer_core::session::apply: apply: repaint ms=855
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #14 — `https://news.ycombinator.com/`
- **Horodatage** : 2026-10-26 12:45:56
- **URL testée** : https://news.ycombinator.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-56_EQUIPE_1_DOCS_news.ycombinator.com_.png` (3472.9 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-56_EQUIPE_1_DOCS_news.ycombinator.com_.png â€” 3556295 octets

2026-10-26T11:45:56.577977Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:57.379369Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=801
2026-10-26T11:45:57.384060Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=806
2026-10-26T11:45:57.929610Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1351
2026-10-26T11:45:57.930406Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=5217
2026-10-26T11:45:57.936830Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=true
2026-10-26T11:45:58.053682Z  INFO explorer_core::session::apply: apply: cascade ms=114
2026-10-26T11:45:58.094648Z  INFO explorer_core::session::apply: apply: boxtree ms=155
2026-10-26T11:45:58.618034Z  INFO explorer_core::session::apply: apply: layout ms=679
2026-10-26T11:45:58.742119Z  INFO explorer_core::session::apply: apply: repaint ms=803
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #15 — `https://info.cern.ch/`
- **Horodatage** : 2026-10-26 12:46:29
- **URL testée** : https://info.cern.ch/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-46-29_EQUIPE_1_DOCS_info.cern.ch_.png` (1175.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-46-29_EQUIPE_1_DOCS_info.cern.ch_.png â€” 1203164 octets

2026-10-26T11:46:29.735434Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:29.904744Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=169
2026-10-26T11:46:29.905014Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=169
2026-10-26T11:46:29.907444Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=172
2026-10-26T11:46:29.910785Z  INFO explorer_core::session::apply: apply: cascade ms=3
2026-10-26T11:46:29.911221Z  INFO explorer_core::session::apply: apply: boxtree ms=3
2026-10-26T11:46:29.950053Z  INFO explorer_core::session::apply: apply: layout ms=42
2026-10-26T11:46:29.976309Z  INFO explorer_core::session::apply: apply: repaint ms=68
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #16 — `https://text.npr.org/`
- **Horodatage** : 2026-10-26 12:47:06
- **URL testée** : https://text.npr.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-47-06_EQUIPE_1_DOCS_text.npr.org_.png` (2316.9 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-47-06_EQUIPE_1_DOCS_text.npr.org_.png â€” 2372462 octets

2026-10-26T11:47:06.921719Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:47:07.017952Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=96
2026-10-26T11:47:07.018832Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=97
2026-10-26T11:47:07.022146Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=100
2026-10-26T11:47:07.033827Z  INFO explorer_core::session::apply: apply: cascade ms=11
2026-10-26T11:47:07.036492Z  INFO explorer_core::session::apply: apply: boxtree ms=14
2026-10-26T11:47:07.309371Z  INFO explorer_core::session::apply: apply: layout ms=287
2026-10-26T11:47:07.371488Z  INFO explorer_core::session::apply: apply: repaint ms=349
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #17 — `https://en.wikipedia.org/wiki/Main_Page`
- **Horodatage** : 2026-10-26 12:47:50
- **URL testée** : https://en.wikipedia.org/wiki/Main_Page
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-47-50_EQUIPE_1_DOCS_en.wikipedia.org_wiki_Main_Page.png` (14222.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-47-50_EQUIPE_1_DOCS_en.wikipedia.org_wiki_Main_Page.png â€” 14563401 octets

2026-10-26T11:47:50.269093Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:47:50.565210Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=296
2026-10-26T11:47:50.580073Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=310
2026-10-26T11:47:51.760808Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1491
2026-10-26T11:47:51.763053Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4312
2026-10-26T11:47:51.775352Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=12 ok=true
2026-10-26T11:47:51.775400Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=214
2026-10-26T11:47:51.776020Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:51.776047Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1508
2026-10-26T11:47:51.776655Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:47:53.902695Z  INFO explorer_core::session::apply: apply: cascade ms=1330
2026-10-26T11:47:53.989572Z  INFO explorer_core::session::apply: apply: boxtree ms=1417
2026-10-26T11:47:55.356180Z  INFO explorer_core::session::apply: apply: layout ms=2784
2026-10-26T11:47:56.242777Z  INFO explorer_core::session::apply: apply: repaint ms=3670
2026-10-26T11:47:56.932801Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:47:59.754110Z  INFO explorer_core::session::apply: apply: cascade ms=1337
2026-10-26T11:47:59.835616Z  INFO explorer_core::session::apply: apply: boxtree ms=1419
2026-10-26T11:47:59.982006Z  INFO explorer_core::session::apply: apply: layout ms=1565
2026-10-26T11:48:00.625926Z  INFO explorer_core::session::apply: apply: repaint ms=2209
2026-10-26T11:48:00.700496Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=3767
[journal : 0 appliquÃ©s / 0 replis / 13 classÃ©es]
```

---

### ✈️ Vol #18 — `https://developer.mozilla.org/en-US/`
- **Horodatage** : 2026-10-26 12:48:30
- **URL testée** : https://developer.mozilla.org/en-US/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-48-30_EQUIPE_1_DOCS_developer.mozilla.org_en-US_.png` (7698.6 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-48-30_EQUIPE_1_DOCS_developer.mozilla.org_en-US_.png â€” 7883331 octets

2026-10-26T11:48:30.176127Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:48:30.341231Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=165
2026-10-26T11:48:30.349260Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=173
2026-10-26T11:48:32.081228Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1905
2026-10-26T11:48:34.838068Z DEBUG explorer_jscore::module: import() dynamique spec="./7489.cd806d2f427a883d.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.840895Z DEBUG explorer_jscore::module: import() dynamique spec="./3708.4a0422a33ccb46ea.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.843594Z DEBUG explorer_jscore::module: import() dynamique spec="./8280.d23400460d00c14a.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.846279Z DEBUG explorer_jscore::module: import() dynamique spec="./1477.2e21275901ede190.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.848993Z DEBUG explorer_jscore::module: import() dynamique spec="./4249.f72e3bc533441dbe.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.851691Z DEBUG explorer_jscore::module: import() dynamique spec="./9204.6afe342b1a966b73.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.854912Z DEBUG explorer_jscore::module: import() dynamique spec="./3690.dde3c3c4604a6af2.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.857975Z DEBUG explorer_jscore::module: import() dynamique spec="./2868.72600e71ae8128fe.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.867983Z DEBUG explorer_jscore::module: import() dynamique spec="./8121.0d3b90f48eb7f970.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.870804Z DEBUG explorer_jscore::module: import() dynamique spec="./3711.97606c6489b00a61.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.874246Z DEBUG explorer_jscore::module: import() dynamique spec="./5542.1e868b3ebf533fa2.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.877632Z DEBUG explorer_jscore::module: import() dynamique spec="./9099.d5fd55aa8af08e99.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.880524Z DEBUG explorer_jscore::module: import() dynamique spec="./9647.28b4240dbab81568.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.883260Z DEBUG explorer_jscore::module: import() dynamique spec="./8926.2bd0c75389285bbf.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.886034Z DEBUG explorer_jscore::module: import() dynamique spec="./1996.e833c07cb4ee4327.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.889363Z DEBUG explorer_jscore::module: import() dynamique spec="./7678.dfaf3192e6619d2b.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.895844Z DEBUG explorer_jscore::module: import() dynamique spec="./4759.406acbfe352fc5fc.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.903194Z DEBUG explorer_jscore::module: import() dynamique spec="./4060.8abfad3012e87803.js" referrer="https://developer.mozilla.org/static/client/runtime.231db49498ee594b.js"
2026-10-26T11:48:34.954150Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-button
2026-10-26T11:48:34.954911Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-search-modal
2026-10-26T11:48:37.049264Z  INFO explorer_core::session::apply: apply: cascade ms=723
2026-10-26T11:48:37.154480Z  INFO explorer_core::session::apply: apply: boxtree ms=828
2026-10-26T11:48:37.831581Z  INFO explorer_core::session::apply: apply: layout ms=1505
2026-10-26T11:48:38.124622Z  INFO explorer_core::session::apply: apply: repaint ms=1798
2026-10-26T11:48:38.300433Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-dropdown
2026-10-26T11:48:38.315244Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-homepage-search
2026-10-26T11:48:38.318413Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-search-button
2026-10-26T11:48:38.345325Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-color-theme
2026-10-26T11:48:38.367378Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-user-menu
2026-10-26T11:48:38.380362Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-switch
2026-10-26T11:48:38.381228Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-language-switcher
2026-10-26T11:48:38.436834Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-placement-no
2026-10-26T11:48:38.438925Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-placement-note
2026-10-26T11:48:38.440715Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-placement-top
2026-10-26T11:48:38.445030Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-placement-hp-main
2026-10-26T11:48:38.449051Z DEBUG explorer_jscore::dom_host: customElements.define name=mdn-placement-bottom
2026-10-26T11:48:38.762134Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:48:38.762236Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:48:38.768546Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:48:39.591832Z  INFO explorer_core::session::apply: apply: cascade ms=759
2026-10-26T11:48:39.680157Z  INFO explorer_core::session::apply: apply: boxtree ms=847
2026-10-26T11:48:39.742516Z  INFO explorer_core::session::apply: apply: layout ms=909
2026-10-26T11:48:40.030615Z  INFO explorer_core::session::apply: apply: repaint ms=1198
2026-10-26T11:48:40.041807Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1273
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #19 — `https://lobste.rs/`
- **Horodatage** : 2026-10-26 12:50:28
- **URL testée** : https://lobste.rs/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-50-28_EQUIPE_1_DOCS_lobste.rs_.png` (5509.4 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-50-28_EQUIPE_1_DOCS_lobste.rs_.png â€” 5641634 octets

2026-10-26T11:50:28.844578Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:50:29.380373Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=535
2026-10-26T11:50:29.387904Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=543
2026-10-26T11:50:30.505363Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1660
2026-10-26T11:50:30.871056Z  INFO explorer_core::session::apply: apply: cascade ms=356
2026-10-26T11:50:30.906453Z  INFO explorer_core::session::apply: apply: boxtree ms=391
2026-10-26T11:50:31.253807Z  INFO explorer_core::session::apply: apply: layout ms=738
2026-10-26T11:50:31.514855Z  INFO explorer_core::session::apply: apply: repaint ms=999
2026-10-26T11:50:31.562822Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:50:31.562901Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=NoBaseline
2026-10-26T11:50:31.604323Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:50:32.012195Z  INFO explorer_core::session::apply: apply: cascade ms=357
2026-10-26T11:50:32.040548Z  INFO explorer_core::session::apply: apply: boxtree ms=385
2026-10-26T11:50:32.154395Z  INFO explorer_core::session::apply: apply: layout ms=499
2026-10-26T11:50:32.474837Z  INFO explorer_core::session::apply: apply: repaint ms=819
2026-10-26T11:50:32.531840Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=927
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #20 — `https://www.w3.org/`
- **Horodatage** : 2026-10-26 12:51:09
- **URL testée** : https://www.w3.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-51-09_EQUIPE_1_DOCS_www.w3.org_.png` (20495.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-51-09_EQUIPE_1_DOCS_www.w3.org_.png â€” 20987432 octets

2026-10-26T11:51:09.699467Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:51:09.816430Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=116
2026-10-26T11:51:09.820142Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=120
2026-10-26T11:51:10.862245Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1162
2026-10-26T11:51:10.862810Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=6042
2026-10-26T11:51:10.870542Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=7 ok=true
2026-10-26T11:51:10.870593Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=743
2026-10-26T11:51:10.874124Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:51:10.874171Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=18014
2026-10-26T11:51:10.877604Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:51:10.877647Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=216
2026-10-26T11:51:10.879759Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:51:13.303088Z  INFO explorer_core::session::apply: apply: cascade ms=359
2026-10-26T11:51:13.317101Z  INFO explorer_core::session::apply: apply: boxtree ms=373
2026-10-26T11:51:13.825481Z  INFO explorer_core::session::apply: apply: layout ms=881
2026-10-26T11:51:15.323572Z  INFO explorer_core::session::apply: apply: repaint ms=2379
2026-10-26T11:51:15.433500Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:51:15.433597Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:51:15.445849Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:51:15.836917Z  INFO explorer_core::session::apply: apply: cascade ms=372
2026-10-26T11:51:15.852998Z  INFO explorer_core::session::apply: apply: boxtree ms=388
2026-10-26T11:51:15.909506Z  INFO explorer_core::session::apply: apply: layout ms=445
2026-10-26T11:51:17.389932Z  INFO explorer_core::session::apply: apply: repaint ms=1925
2026-10-26T11:51:17.404105Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1958
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #21 — `https://www.gnu.org/`
- **Horodatage** : 2026-10-26 12:52:09
- **URL testée** : https://www.gnu.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-52-09_EQUIPE_1_DOCS_www.gnu.org_.png` (7389.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-52-09_EQUIPE_1_DOCS_www.gnu.org_.png â€” 7566355 octets

2026-10-26T11:52:09.438836Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:52:09.974240Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=535
2026-10-26T11:52:09.977868Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=539
2026-10-26T11:52:11.433070Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1994
2026-10-26T11:52:12.590230Z  INFO explorer_core::session::apply: apply: cascade ms=128
2026-10-26T11:52:12.605881Z  INFO explorer_core::session::apply: apply: boxtree ms=144
2026-10-26T11:52:13.334044Z  INFO explorer_core::session::apply: apply: layout ms=872
2026-10-26T11:52:14.059481Z  INFO explorer_core::session::apply: apply: repaint ms=1597
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #22 — `https://doc.rust-lang.org/book/`
- **Horodatage** : 2026-10-26 12:52:50
- **URL testée** : https://doc.rust-lang.org/book/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-52-50_EQUIPE_1_DOCS_doc.rust-lang.org_book_.png` (1338.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-52-50_EQUIPE_1_DOCS_doc.rust-lang.org_book_.png â€” 1370610 octets

2026-10-26T11:52:51.103113Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:52:51.272688Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=169
2026-10-26T11:52:51.274413Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=171
2026-10-26T11:52:55.845829Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=4742
2026-10-26T11:52:55.846106Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=213
2026-10-26T11:52:55.846428Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:55.846451Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=41494
2026-10-26T11:52:55.854716Z DEBUG explorer_jscore::dom_host: customElements.define name=mdbook-sidebar-scrollbox
2026-10-26T11:52:56.145233Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=298 ok=true
2026-10-26T11:52:56.145286Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=559
2026-10-26T11:52:56.145587Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:56.145605Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=500
2026-10-26T11:52:56.145933Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:56.145950Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=621
2026-10-26T11:52:56.146517Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:56.146533Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=469
2026-10-26T11:52:56.152913Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=true
2026-10-26T11:52:56.152936Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=56
2026-10-26T11:52:56.153057Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:56.153082Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=18051
2026-10-26T11:52:56.244137Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=91 ok=true
2026-10-26T11:52:56.244197Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=17320
2026-10-26T11:52:56.266600Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=22 ok=true
2026-10-26T11:52:56.266659Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=20294
2026-10-26T11:52:56.282400Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=15 ok=true
2026-10-26T11:52:56.282458Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=10754
2026-10-26T11:52:56.289397Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=true
2026-10-26T11:52:56.289432Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=137537
2026-10-26T11:52:57.530378Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1240 ok=true
2026-10-26T11:52:57.530440Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=30932
2026-10-26T11:52:57.590081Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=59 ok=true
2026-10-26T11:52:57.590140Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2653
2026-10-26T11:52:57.590965Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:52:57.748483Z  INFO explorer_core::session::apply: apply: cascade ms=138
2026-10-26T11:52:58.105524Z  INFO explorer_core::session::apply: apply: boxtree ms=495
2026-10-26T11:52:58.265772Z  INFO explorer_core::session::apply: apply: layout ms=655
2026-10-26T11:52:58.510737Z  INFO explorer_core::session::apply: apply: repaint ms=900
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```
