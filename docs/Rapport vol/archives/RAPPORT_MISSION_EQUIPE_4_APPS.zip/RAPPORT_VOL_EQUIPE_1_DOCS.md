# 📜 Journal de Vol Permanent & Fiches Détaillées : Équipe 1 (Docs & Médias)

*Ce document conserve l'intégralité des vols sans jamais rien écraser. Chaque vol ajoute sa ligne au tableau récapitulatif ET sa fiche technique détaillée ci-dessous.*

---

## 📊 Tableau Récapitulatif Chronologique (26 vols)

| N° | Horodatage | Site internet | Statut | Poids Frame | Diagnostic / Observation |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 11:55:11 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | [Voir Détail #1](#vol-1--examplecom) — Rendu nominal rapide (235 ms) |
| 2 | 2026-10-26 11:55:26 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | [Voir Détail #2](#vol-2--newsycombinatorcom) — Scripts évalués en 8 ms |
| 3 | 2026-10-26 11:56:50 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | [Voir Détail #3](#vol-3--wikipedia-main-page) — Layout encyclopédique lourd |
| 4 | 2026-10-26 11:57:18 | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | [Voir Détail #4](#vol-4--mdn) — journal DOM rejeté why=UnmappedKey |
| 5 | 2026-10-26 11:57:54 | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5550.0 Ko | [Voir Détail #5](#vol-5--lobsters) — journal DOM rejeté why=NoBaseline |
| 6 | 2026-10-26 11:58:13 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | [Voir Détail #6](#vol-6--infocernch) — HTML hypertexte standard |
| 7 | 2026-10-26 11:59:41 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | [Voir Détail #7](#vol-7--textnprorg) — Rendu textuel immédiat |
| 8 | 2026-10-26 11:59:56 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | [Voir Détail #8](#vol-8--examplecom) — Rendu nominal |
| 9 | 2026-10-26 12:00:16 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | [Voir Détail #9](#vol-9--newsycombinatorcom) — Rendu nominal |
| 10 | 2026-10-26 12:00:34 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | [Voir Détail #10](#vol-10--wikipedia-main-page) — Rendu nominal |
| 11 | 2026-10-26 12:02:14 | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | [Voir Détail #11](#vol-11--mdn) — journal DOM rejeté why=UnmappedKey |
| 12 | 2026-10-26 12:02:43 | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5549.0 Ko | [Voir Détail #12](#vol-12--lobsters) — journal DOM rejeté why=NoBaseline |
| 13 | 2026-10-26 12:03:06 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | [Voir Détail #13](#vol-13--infocernch) — Rendu nominal |
| 14 | 2026-10-26 12:03:15 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | [Voir Détail #14](#vol-14--textnprorg) — Rendu nominal |
| 15 | 2026-10-26 12:04:49 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | [Voir Détail #15](#vol-15--examplecom) — Rendu nominal |
| 16 | 2026-10-26 12:05:10 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | [Voir Détail #16](#vol-16--newsycombinatorcom) — Rendu nominal |
| 17 | 2026-10-26 12:05:35 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | [Voir Détail #17](#vol-17--wikipedia-main-page) — Rendu nominal |
| 18 | 2026-10-26 12:06:00 | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | [Voir Détail #18](#vol-18--mdn) — journal DOM rejeté why=UnmappedKey |
| 19 | 2026-10-26 12:07:35 | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5549.6 Ko | [Voir Détail #19](#vol-19--lobsters) — journal DOM rejeté why=NoBaseline |
| 20 | 2026-10-26 12:07:59 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | [Voir Détail #20](#vol-20--infocernch) — Rendu nominal |
| 21 | 2026-10-26 12:08:24 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | [Voir Détail #21](#vol-21--textnprorg) — Rendu nominal |
| 22 | 2026-10-26 12:08:37 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | [Voir Détail #22](#vol-22--examplecom) — Rendu nominal |
| 23 | 2026-10-26 12:10:02 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | [Voir Détail #23](#vol-23--newsycombinatorcom) — Rendu nominal |
| 24 | 2026-10-26 12:10:19 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | [Voir Détail #24](#vol-24--wikipedia-main-page) — Rendu nominal |
| 25 | 2026-10-26 12:10:56 | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | [Voir Détail #25](#vol-25--mdn) — journal DOM rejeté why=UnmappedKey |
| 26 | 2026-10-26 12:11:22 | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5549.6 Ko | [Voir Détail #26](#vol-26--lobsters) — journal DOM rejeté why=NoBaseline |

---

## 🔍 Fiches Techniques Détaillées des Vols

### <a id="vol-1--examplecom"></a>Vol #1 — `https://example.com/` (2026-10-26 11:55:11)
- **Cible** : Domaine témoin IANA
- **Statut** : 🟢 OK
- **Poids Frame** : 1 259.9 Ko
- **Temps commit** : 235 ms
- **Observations** : Le document est téléchargé via HTTP/1.1 TLS, parsé par `explorer-html`, stylé via `explorer-css` et rasterisé par `explorer-render` sans aucun avertissement.

---

### <a id="vol-2--newsycombinatorcom"></a>Vol #2 — `https://news.ycombinator.com/` (2026-10-26 11:55:26)
- **Cible** : Hacker News
- **Statut** : 🟢 OK
- **Poids Frame** : 3 472.7 Ko
- **Temps commit** : 1 219 ms
- **Observations** : Layout basé sur des tableaux HTML imbriqués (`<table>`). Les scripts d'affichage et de vote (5 217 octets) sont évalués en 8 ms avec succès (`ok=true`).

---

### <a id="vol-3--wikipedia-main-page"></a>Vol #3 — `https://en.wikipedia.org/wiki/Main_Page` (2026-10-26 11:56:50)
- **Cible** : Wikipedia Accueil
- **Statut** : 🟢 OK
- **Poids Frame** : 14 222.1 Ko
- **Observations** : Page encyclopédique volumineuse. Arbre DOM de plusieurs milliers de nœuds. Gestion des images miniatures et typographie UTF-8 multi-script (latin, cyrillique, kanji) nominale.

---

### <a id="vol-4--mdn"></a>Vol #4 — `https://developer.mozilla.org/en-US/` (2026-10-26 11:57:18)
- **Cible** : MDN Web Docs
- **Statut** : ⚠️ REPLI_DOM (Dégradation gracieuse)
- **Poids Frame** : 7 698.6 Ko
- **Trace brute capturée** :
  ```text
  2026-10-26T10:43:47.261544Z INFO explorer_core::session::apply: apply: début tab=1 journal=true
  2026-10-26T10:43:47.261671Z WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=UnmappedKey
  2026-10-26T10:43:47.268086Z INFO explorer_core::session::apply: apply: début tab=1 journal=false
  ```
- **Diagnostic Code Source Rust** :
  Fichier `crates/explorer-core/src/session/apply.rs`.  
  Une opération de journal incrémental référence une clé de nœud non trouvée dans le mapping. Le moteur applique la décision d'architecture ADR-0025 en basculant sur un re-parse complet sans paniquer ni altérer l'affichage.

---

### <a id="vol-5--lobsters"></a>Vol #5 — `https://lobste.rs/` (2026-10-26 11:57:54)
- **Cible** : Lobste.rs
- **Statut** : ⚠️ REPLI_DOM
- **Poids Frame** : 5 550.0 Ko
- **Trace brute capturée** :
  ```text
  2026-10-26T10:53:45.503151Z WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=NoBaseline
  ```
- **Diagnostic Code Source Rust** :
  Absence d'état de base (`NoBaseline`) lors de l'application de la mutation incrémentale. Le repli re-parse prend le relais et produit la frame finale sans encombre.
| 2026-10-26 12:25:01 | `https://news.ycombinator.com/` | **🟢 OK** | 3473.5 Ko | Rendu nominal |
| 2026-10-26 12:25:19 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 2026-10-26 12:27:03 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 2026-10-26 12:27:32 | `https://lobste.rs/` | **🟢 OK** | 5513.6 Ko | Rendu nominal |
| 2026-10-26 12:27:55 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 2026-10-26 12:28:05 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 2026-10-26 12:29:33 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 2026-10-26 12:29:53 | `https://news.ycombinator.com/` | **🟢 OK** | 3473.5 Ko | Rendu nominal |
| 2026-10-26 12:30:19 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 2026-10-26 12:30:40 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 2026-10-26 12:32:12 | `https://lobste.rs/` | **🟢 OK** | 5543.2 Ko | Rendu nominal |
| 2026-10-26 12:32:37 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 2026-10-26 12:33:01 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 2026-10-26 12:33:15 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 2026-10-26 12:34:38 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 2026-10-26 12:34:56 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 2026-10-26 12:35:33 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 2026-10-26 12:36:00 | `https://lobste.rs/` | **🟢 OK** | 5509.8 Ko | Rendu nominal |
| 2026-10-26 12:37:32 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 2026-10-26 12:37:46 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 2026-10-26 12:38:07 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 2026-10-26 12:38:22 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 2026-10-26 12:39:54 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 2026-10-26 12:40:25 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 2026-10-26 12:40:57 | `https://lobste.rs/` | **🟢 OK** | 5544.6 Ko | Rendu nominal |
| 2026-10-26 12:41:11 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 2026-10-26 12:42:40 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 2026-10-26 12:43:01 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 2026-10-26 12:43:25 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 2026-10-26 12:43:36 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 2026-10-26 12:45:13 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 2026-10-26 12:45:44 | `https://lobste.rs/` | **🟢 OK** | 5544.9 Ko | Rendu nominal |
| 2026-10-26 12:46:13 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 2026-10-26 12:46:27 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 2026-10-26 12:47:50 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 2026-10-26 12:48:06 | `https://news.ycombinator.com/` | **🟢 OK** | 3473.0 Ko | Rendu nominal |
| 2026-10-26 12:48:33 | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 2026-10-26 12:49:00 | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 2026-10-26 12:50:37 | `https://lobste.rs/` | **🟢 OK** | 5509.5 Ko | Rendu nominal |
| 2026-10-26 12:50:56 | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 2026-10-26 12:51:15 | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 2026-10-26 12:51:32 | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 2026-10-26 12:53:02 | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
