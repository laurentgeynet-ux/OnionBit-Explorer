# 🛰️ RAPPORT DE MISSION EN VOL : ÉQUIPE 2 : SPAS & FRAMEWORKS JS (SITES INÉDITS)

*Rapport d'exploration inédit (100% nouveaux sites). Aucun ancien site validé.*

## 📋 Tableau Récapitulatif Chronologique

| N° | Horodatage | Site internet inédit | Statut | Poids Frame | Constat / Mur détecté |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 12:43:16 | `https://htmx.org/` | **🟢 OK** | 7943.7 Ko | Rendu nominal réussi |
| 2 | 2026-10-26 12:43:47 | `https://alpinejs.dev/` | **🔴 FAIL** | 0.0 Ko | Rendu nominal réussi |
| 11 | 2026-10-26 12:43:55 | `https://react.dev/` | **🟢 OK** | 40267.1 Ko | Rendu nominal réussi |
| 3 | 2026-10-26 12:44:30 | `https://preactjs.com/` | **🟢 OK** | 11607.8 Ko | Rendu nominal réussi |
| 12 | 2026-10-26 12:44:53 | `https://stimulus.hotwired.dev/` | **🟢 OK** | 3270.5 Ko | Rendu nominal réussi |
| 4 | 2026-10-26 12:45:07 | `https://svelte.dev/` | **🟢 OK** | 8004.1 Ko | Rendu nominal réussi |
| 13 | 2026-10-26 12:45:27 | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal réussi |
| 5 | 2026-10-26 12:45:46 | `https://solidjs.com/` | **🟢 OK** | 1156.7 Ko | Rendu nominal réussi |
| 14 | 2026-10-26 12:46:02 | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal réussi |
| 15 | 2026-10-26 12:46:33 | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal réussi |
| 16 | 2026-10-26 12:47:10 | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal réussi |
| 17 | 2026-10-26 12:48:05 | `https://htmx.org/` | **🟢 OK** | 7943.7 Ko | Rendu nominal réussi |
| 18 | 2026-10-26 12:48:44 | `https://alpinejs.dev/` | **🔴 FAIL** | 0.0 Ko | Rendu nominal réussi |
| 19 | 2026-10-26 12:50:36 | `https://preactjs.com/` | **🟢 OK** | 11607.8 Ko | Rendu nominal réussi |
| 20 | 2026-10-26 12:51:22 | `https://svelte.dev/` | **🟢 OK** | 8004.1 Ko | Rendu nominal réussi |
| 21 | 2026-10-26 12:52:17 | `https://solidjs.com/` | **🟢 OK** | 1156.7 Ko | Rendu nominal réussi |
| 22 | 2026-10-26 12:53:02 | `https://lit.dev/` | **🟢 OK** | 1152.3 Ko | Rendu nominal réussi |


## 🔍 Fiches Détaillées par Vol

---

### ✈️ Vol #1 — `https://htmx.org/`
- **Horodatage** : 2026-10-26 12:43:16
- **URL testée (Inédite)** : https://htmx.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-16_EQUIPE_2_JS_htmx.org_.png` (7943.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-16_EQUIPE_2_JS_htmx.org_.png â€” 8134378 octets

2026-10-26T11:43:16.814788Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:16.977468Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=162
2026-10-26T11:43:16.980373Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=165
2026-10-26T11:43:17.745848Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=931
2026-10-26T11:43:17.749972Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=171362
2026-10-26T11:43:17.837671Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=87 ok=false
2026-10-26T11:43:17.851584Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3293
2026-10-26T11:43:17.856128Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=4 ok=false
2026-10-26T11:43:17.856500Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4752
2026-10-26T11:43:17.857464Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:43:17.857963Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=101285
2026-10-26T11:43:17.920676Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=62 ok=true
2026-10-26T11:43:17.920731Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=287
2026-10-26T11:43:17.920977Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:17.924514Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:43:17.924565Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=NoBaseline
2026-10-26T11:43:17.924604Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:43:18.046801Z  INFO explorer_core::session::apply: apply: cascade ms=109
2026-10-26T11:43:18.059536Z  INFO explorer_core::session::apply: apply: boxtree ms=121
2026-10-26T11:43:18.460313Z  INFO explorer_core::session::apply: apply: layout ms=522
2026-10-26T11:43:18.877237Z  INFO explorer_core::session::apply: apply: repaint ms=939
2026-10-26T11:43:18.889430Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=964
2026-10-26T11:43:21.952601Z  INFO explorer_core::session::apply: apply: cascade ms=103
2026-10-26T11:43:21.965191Z  INFO explorer_core::session::apply: apply: boxtree ms=116
2026-10-26T11:43:22.020528Z  INFO explorer_core::session::apply: apply: layout ms=171
2026-10-26T11:43:22.385368Z  INFO explorer_core::session::apply: apply: repaint ms=536
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #2 — `https://alpinejs.dev/`
- **Horodatage** : 2026-10-26 12:43:47
- **URL testée (Inédite)** : https://alpinejs.dev/
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-43-47_EQUIPE_2_JS_alpinejs.dev_.png` (0.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:43:47.980421Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:48.271261Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=290
2026-10-26T11:43:48.275818Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=295
2026-10-26T11:43:49.014411Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1034
2026-10-26T11:43:49.015185Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=208
2026-10-26T11:43:49.015630Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.015687Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=159822
2026-10-26T11:43:49.176155Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=160 ok=true
2026-10-26T11:43:49.176207Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=539
2026-10-26T11:43:49.176680Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.176710Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=133239
2026-10-26T11:43:49.310650Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=133 ok=true
2026-10-26T11:43:49.310711Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=320
2026-10-26T11:43:49.364017Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=53 ok=true
2026-10-26T11:43:49.364085Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2002
2026-10-26T11:43:49.366882Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:43:49.366912Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=929
2026-10-26T11:43:49.367617Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.367637Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=26051
2026-10-26T11:43:49.387786Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=20 ok=true
2026-10-26T11:43:49.387827Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1448
2026-10-26T11:43:49.390873Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:43:49.390900Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=5451
2026-10-26T11:43:49.394114Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:43:49.394133Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=945
2026-10-26T11:43:49.394724Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:49.394742Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2063
2026-10-26T11:43:49.399852Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=5 ok=true
2026-10-26T11:43:49.399878Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=38866
2026-10-26T11:43:49.468950Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=69 ok=true
2026-10-26T11:43:49.469012Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=15664
2026-10-26T11:43:49.480146Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=11 ok=true
2026-10-26T11:43:49.480231Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=41063
2026-10-26T11:43:49.497331Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=17 ok=true
2026-10-26T11:43:49.497415Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=55935

thread 'explorer-jscore' (20064) has overflowed its stack
```

---

### ✈️ Vol #11 — `https://react.dev/`
- **Horodatage** : 2026-10-26 12:43:55
- **URL testée** : https://react.dev/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-43-55_EQUIPE_2_JS_react.dev_.png` (40267.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-43-55_EQUIPE_2_JS_react.dev_.png â€” 41233532 octets

2026-10-26T11:43:55.497963Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:43:55.715597Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=217
2026-10-26T11:43:55.725005Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=227
2026-10-26T11:43:59.396694Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=3898
2026-10-26T11:43:59.398325Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=139
2026-10-26T11:43:59.463411Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=65 ok=true
2026-10-26T11:43:59.463462Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2168
2026-10-26T11:43:59.464186Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:59.464211Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1875
2026-10-26T11:43:59.464917Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:43:59.464951Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4077
2026-10-26T11:43:59.467578Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:43:59.467605Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=181788
2026-10-26T11:43:59.574071Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=106 ok=true
2026-10-26T11:43:59.574135Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=130717
2026-10-26T11:43:59.791013Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=216 ok=true
2026-10-26T11:43:59.791075Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1235
2026-10-26T11:43:59.804178Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=13 ok=true
2026-10-26T11:43:59.804234Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=101632
2026-10-26T11:43:59.865264Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=61 ok=true
2026-10-26T11:43:59.865324Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=307314
2026-10-26T11:43:59.991685Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=126 ok=true
2026-10-26T11:43:59.991748Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=14145
2026-10-26T11:44:00.047071Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=55 ok=true
2026-10-26T11:44:00.047130Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1201
2026-10-26T11:44:00.047684Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:44:00.047710Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=154
2026-10-26T11:44:00.047912Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:44:05.703968Z  INFO explorer_core::session::apply: apply: cascade ms=3504
2026-10-26T11:44:06.020319Z  INFO explorer_core::session::apply: apply: boxtree ms=3820
2026-10-26T11:44:07.107722Z  INFO explorer_core::session::apply: apply: layout ms=4907
2026-10-26T11:44:10.880245Z  INFO explorer_core::session::apply: apply: repaint ms=8680
2026-10-26T11:44:11.091070Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:44:11.093422Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=Fingerprint
2026-10-26T11:44:11.166046Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:44:14.828838Z  INFO explorer_core::session::apply: apply: cascade ms=3579
2026-10-26T11:44:15.144881Z  INFO explorer_core::session::apply: apply: boxtree ms=3895
2026-10-26T11:44:15.398007Z  INFO explorer_core::session::apply: apply: layout ms=4148
2026-10-26T11:44:19.694141Z  INFO explorer_core::session::apply: apply: repaint ms=8445
2026-10-26T11:44:19.788629Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=8622
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #3 — `https://preactjs.com/`
- **Horodatage** : 2026-10-26 12:44:30
- **URL testée (Inédite)** : https://preactjs.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-30_EQUIPE_2_JS_preactjs.com_.png` (11607.8 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-30_EQUIPE_2_JS_preactjs.com_.png â€” 11886345 octets

2026-10-26T11:44:30.658949Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:30.858710Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=199
2026-10-26T11:44:30.864932Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=205
2026-10-26T11:44:31.789756Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1130
2026-10-26T11:44:31.790869Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=163
2026-10-26T11:44:31.791955Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:44:33.130316Z  INFO explorer_core::session::apply: apply: cascade ms=661
2026-10-26T11:44:33.420247Z  INFO explorer_core::session::apply: apply: boxtree ms=951
2026-10-26T11:44:34.204750Z  INFO explorer_core::session::apply: apply: layout ms=1735
2026-10-26T11:44:34.882735Z  INFO explorer_core::session::apply: apply: repaint ms=2413
2026-10-26T11:44:35.150111Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:44:35.152270Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=Fingerprint
2026-10-26T11:44:35.225900Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:44:35.949979Z  INFO explorer_core::session::apply: apply: cascade ms=692
2026-10-26T11:44:36.243085Z  INFO explorer_core::session::apply: apply: boxtree ms=985
2026-10-26T11:44:36.482381Z  INFO explorer_core::session::apply: apply: layout ms=1224
2026-10-26T11:44:37.135043Z  INFO explorer_core::session::apply: apply: repaint ms=1877
2026-10-26T11:44:37.214517Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1988
2026-10-26T11:44:37.217192Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:44:37.219224Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=Fingerprint
2026-10-26T11:44:37.292981Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:44:38.009215Z  INFO explorer_core::session::apply: apply: cascade ms=684
2026-10-26T11:44:38.303566Z  INFO explorer_core::session::apply: apply: boxtree ms=979
2026-10-26T11:44:38.530585Z  INFO explorer_core::session::apply: apply: layout ms=1206
2026-10-26T11:44:39.228045Z  INFO explorer_core::session::apply: apply: repaint ms=1903
2026-10-26T11:44:39.308812Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=2015
[journal : 0 appliquÃ©s / 2 replis / 0 classÃ©es]
```

---

### ✈️ Vol #12 — `https://stimulus.hotwired.dev/`
- **Horodatage** : 2026-10-26 12:44:53
- **URL testée** : https://stimulus.hotwired.dev/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-44-53_EQUIPE_2_JS_stimulus.hotwired.dev_.png` (3270.5 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-44-53_EQUIPE_2_JS_stimulus.hotwired.dev_.png â€” 3349034 octets

2026-10-26T11:44:53.430841Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:44:53.574457Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=143
2026-10-26T11:44:53.576518Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=145
2026-10-26T11:44:54.287947Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=857
2026-10-26T11:44:54.388047Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-frame
2026-10-26T11:44:54.388213Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-stream
2026-10-26T11:44:54.388335Z DEBUG explorer_jscore::dom_host: customElements.define name=turbo-stream-source
2026-10-26T11:44:54.409151Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2841
2026-10-26T11:44:54.414000Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=4 ok=true
2026-10-26T11:44:54.540933Z  INFO explorer_core::session::apply: apply: cascade ms=90
2026-10-26T11:44:54.772430Z  INFO explorer_core::session::apply: apply: boxtree ms=322
2026-10-26T11:44:55.072723Z  INFO explorer_core::session::apply: apply: layout ms=622
2026-10-26T11:44:55.306351Z  INFO explorer_core::session::apply: apply: repaint ms=856
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #4 — `https://svelte.dev/`
- **Horodatage** : 2026-10-26 12:45:07
- **URL testée (Inédite)** : https://svelte.dev/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-07_EQUIPE_2_JS_svelte.dev_.png` (8004.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-07_EQUIPE_2_JS_svelte.dev_.png â€” 8196154 octets

2026-10-26T11:45:07.280546Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:07.431450Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=150
2026-10-26T11:45:07.436437Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=155
2026-10-26T11:45:24.111236Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=16830
2026-10-26T11:45:24.111726Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=181
2026-10-26T11:45:24.112237Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:24.112285Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=304
2026-10-26T11:45:24.112543Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:24.112570Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=304
2026-10-26T11:45:24.112787Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:24.112804Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=409
2026-10-26T11:45:24.113695Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:24.113715Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=22804
2026-10-26T11:45:24.120353Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=false
2026-10-26T11:45:24.121659Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=409
2026-10-26T11:45:24.122010Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:25.345854Z  INFO explorer_core::session::apply: apply: cascade ms=304
2026-10-26T11:45:25.571163Z  INFO explorer_core::session::apply: apply: boxtree ms=529
2026-10-26T11:45:25.828384Z  INFO explorer_core::session::apply: apply: layout ms=786
2026-10-26T11:45:26.700020Z  INFO explorer_core::session::apply: apply: repaint ms=1658
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #13 — `https://todomvc.com/`
- **Horodatage** : 2026-10-26 12:45:27
- **URL testée** : https://todomvc.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-27_EQUIPE_2_JS_todomvc.com_.png` (11267.2 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-27_EQUIPE_2_JS_todomvc.com_.png â€” 11537632 octets

2026-10-26T11:45:28.014728Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:28.264601Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=249
2026-10-26T11:45:28.268038Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=253
2026-10-26T11:45:28.995879Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=981
2026-10-26T11:45:28.996458Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=39223
2026-10-26T11:45:29.049838Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=53 ok=true
2026-10-26T11:45:29.049930Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=6242
2026-10-26T11:45:29.076583Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=26 ok=false
2026-10-26T11:45:29.077086Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=84380
2026-10-26T11:45:29.535075Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=457 ok=false
2026-10-26T11:45:29.539656Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=31819
2026-10-26T11:45:29.578074Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=38 ok=false
2026-10-26T11:45:29.579900Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=6192
2026-10-26T11:45:29.581896Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=false
2026-10-26T11:45:29.582492Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=244
2026-10-26T11:45:29.583084Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:45:29.893134Z  INFO explorer_core::session::apply: apply: cascade ms=210
2026-10-26T11:45:29.911233Z  INFO explorer_core::session::apply: apply: boxtree ms=228
2026-10-26T11:45:30.672852Z  INFO explorer_core::session::apply: apply: layout ms=989
2026-10-26T11:45:30.966839Z  INFO explorer_core::session::apply: apply: repaint ms=1283
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #5 — `https://solidjs.com/`
- **Horodatage** : 2026-10-26 12:45:46
- **URL testée (Inédite)** : https://solidjs.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-45-46_EQUIPE_2_JS_solidjs.com_.png` (1156.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-45-46_EQUIPE_2_JS_solidjs.com_.png â€” 1184490 octets

2026-10-26T11:45:47.163264Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:45:47.480685Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=317
2026-10-26T11:45:47.481205Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=317
2026-10-26T11:45:49.745746Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2582
2026-10-26T11:45:49.746008Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=921
2026-10-26T11:45:49.747093Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:45:50.641037Z DEBUG explorer_jscore::module: import() dynamique spec="./directory-229d4631-CtXb6iR0.js" referrer="https://www.solidjs.com/assets/index-By2yNLRO.js"
2026-10-26T11:45:50.641377Z DEBUG explorer_jscore::module: import() dynamique spec="./Home-DzraFOXr.js" referrer="https://www.solidjs.com/assets/index-By2yNLRO.js"
2026-10-26T11:45:50.890497Z  INFO explorer_core::session::apply: apply: cascade ms=162
2026-10-26T11:45:54.968681Z  INFO explorer_core::session::apply: apply: boxtree ms=4240
2026-10-26T11:45:54.972711Z  INFO explorer_core::session::apply: apply: layout ms=4244
2026-10-26T11:45:54.980390Z  INFO explorer_core::session::apply: apply: repaint ms=4252
2026-10-26T11:45:55.146012Z  INFO explorer_core::session::apply: apply: cascade ms=163
2026-10-26T11:45:55.146572Z  INFO explorer_core::session::apply: apply: boxtree ms=164
2026-10-26T11:45:55.147120Z  INFO explorer_core::session::apply: apply: layout ms=164
2026-10-26T11:45:55.147621Z  INFO explorer_core::session::apply: apply: repaint ms=165
2026-10-26T11:45:55.389937Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:45:55.907394Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=517
[journal : 1 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #14 — `https://todomvc.com/examples/backbone/`
- **Horodatage** : 2026-10-26 12:46:02
- **URL testée** : https://todomvc.com/examples/backbone/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-46-02_EQUIPE_2_JS_todomvc.com_examples_backbone_.png` (1165.4 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-46-02_EQUIPE_2_JS_todomvc.com_examples_backbone_.png â€” 1193359 octets

2026-10-26T11:46:02.479546Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:02.726469Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=246
2026-10-26T11:46:02.727279Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=247
2026-10-26T11:46:03.025092Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=545
2026-10-26T11:46:03.025261Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3907
2026-10-26T11:46:03.026503Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=false
2026-10-26T11:46:03.026983Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=682
2026-10-26T11:46:03.027276Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:46:03.027381Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1162
2026-10-26T11:46:03.027704Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:46:03.027855Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4327
2026-10-26T11:46:03.028722Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:46:03.029139Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4789
2026-10-26T11:46:03.030245Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=false
2026-10-26T11:46:03.030668Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=638
2026-10-26T11:46:03.030933Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:46:03.031023Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=599
2026-10-26T11:46:03.031318Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:46:03.031410Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=54
2026-10-26T11:46:03.031509Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:46:03.036850Z  INFO explorer_core::session::apply: apply: cascade ms=4
2026-10-26T11:46:03.037584Z  INFO explorer_core::session::apply: apply: boxtree ms=5
2026-10-26T11:46:03.063592Z  INFO explorer_core::session::apply: apply: layout ms=31
2026-10-26T11:46:03.082074Z  INFO explorer_core::session::apply: apply: repaint ms=49
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #15 — `https://v2.vuejs.org/`
- **Horodatage** : 2026-10-26 12:46:33
- **URL testée** : https://v2.vuejs.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-46-33_EQUIPE_2_JS_v2.vuejs.org_.png` (7851.2 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-46-33_EQUIPE_2_JS_v2.vuejs.org_.png â€” 8039670 octets

2026-10-26T11:46:33.383707Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:46:33.544039Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=160
2026-10-26T11:46:33.548777Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=165
2026-10-26T11:46:34.639102Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1255
2026-10-26T11:46:34.656729Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=434842
2026-10-26T11:46:35.046186Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=389 ok=true
2026-10-26T11:46:35.046237Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=72
2026-10-26T11:46:35.046385Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:35.046406Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=255
2026-10-26T11:46:35.046577Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:35.046601Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=24420
2026-10-26T11:46:35.069336Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=22 ok=true
2026-10-26T11:46:35.069383Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=924
2026-10-26T11:46:35.069847Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:35.069870Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3153
2026-10-26T11:46:35.070675Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:35.070704Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=23300
2026-10-26T11:46:35.127347Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=56 ok=true
2026-10-26T11:46:35.127410Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=147691
2026-10-26T11:46:35.533421Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=406 ok=true
2026-10-26T11:46:35.533472Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=895
2026-10-26T11:46:35.538927Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=5 ok=false
2026-10-26T11:46:35.539075Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1827
2026-10-26T11:46:35.539585Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:46:35.539617Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=6981
2026-10-26T11:46:35.542175Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:46:35.542202Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=16926
2026-10-26T11:46:35.557736Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=15 ok=true
2026-10-26T11:46:35.740115Z  INFO explorer_core::session::apply: apply: cascade ms=139
2026-10-26T11:46:35.758511Z  INFO explorer_core::session::apply: apply: boxtree ms=157
2026-10-26T11:46:35.992831Z  INFO explorer_core::session::apply: apply: layout ms=391
2026-10-26T11:46:36.164677Z  INFO explorer_core::session::apply: apply: repaint ms=563
2026-10-26T11:46:36.732566Z  INFO explorer_core::session::apply: apply: cascade ms=142
2026-10-26T11:46:36.750922Z  INFO explorer_core::session::apply: apply: boxtree ms=160
2026-10-26T11:46:36.788834Z  INFO explorer_core::session::apply: apply: layout ms=198
2026-10-26T11:46:36.908934Z  INFO explorer_core::session::apply: apply: repaint ms=318
2026-10-26T11:46:36.959442Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:46:36.959533Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=UnmappedKey
2026-10-26T11:46:36.971525Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:46:37.139286Z  INFO explorer_core::session::apply: apply: cascade ms=148
2026-10-26T11:46:37.158907Z  INFO explorer_core::session::apply: apply: boxtree ms=168
2026-10-26T11:46:37.198216Z  INFO explorer_core::session::apply: apply: layout ms=207
2026-10-26T11:46:37.258076Z  INFO explorer_core::session::apply: apply: repaint ms=267
2026-10-26T11:46:37.271680Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=300
2026-10-26T11:46:37.957286Z  INFO explorer_core::session::apply: apply: cascade ms=148
2026-10-26T11:46:37.977280Z  INFO explorer_core::session::apply: apply: boxtree ms=168
2026-10-26T11:46:38.016421Z  INFO explorer_core::session::apply: apply: layout ms=207
2026-10-26T11:46:38.053013Z  INFO explorer_core::session::apply: apply: repaint ms=243
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #16 — `https://danilowoz.com/`
- **Horodatage** : 2026-10-26 12:47:10
- **URL testée** : https://danilowoz.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-47-10_EQUIPE_2_JS_danilowoz.com_.png` (6349.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-47-10_EQUIPE_2_JS_danilowoz.com_.png â€” 6501424 octets

2026-10-26T11:47:11.042229Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:47:11.374761Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=332
2026-10-26T11:47:11.377010Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=334
2026-10-26T11:47:13.158252Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2116
2026-10-26T11:47:13.544689Z  INFO explorer_core::session::apply: apply: cascade ms=71
2026-10-26T11:47:13.616464Z  INFO explorer_core::session::apply: apply: boxtree ms=142
2026-10-26T11:47:14.329812Z  INFO explorer_core::session::apply: apply: layout ms=856
2026-10-26T11:47:14.500030Z  INFO explorer_core::session::apply: apply: repaint ms=1026
2026-10-26T11:47:14.572716Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:47:14.572794Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=NoBaseline
2026-10-26T11:47:14.577129Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:47:14.662922Z  INFO explorer_core::session::apply: apply: cascade ms=74
2026-10-26T11:47:14.730165Z  INFO explorer_core::session::apply: apply: boxtree ms=142
2026-10-26T11:47:14.778544Z  INFO explorer_core::session::apply: apply: layout ms=190
2026-10-26T11:47:14.911409Z  INFO explorer_core::session::apply: apply: repaint ms=323
2026-10-26T11:47:14.917126Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=339
2026-10-26T11:47:15.578426Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:47:15.653924Z  INFO explorer_core::session::apply: apply: cascade ms=74
2026-10-26T11:47:15.719096Z  INFO explorer_core::session::apply: apply: boxtree ms=139
2026-10-26T11:47:15.763386Z  INFO explorer_core::session::apply: apply: layout ms=184
2026-10-26T11:47:15.904567Z  INFO explorer_core::session::apply: apply: repaint ms=325
2026-10-26T11:47:15.910258Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=331
[journal : 1 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #17 — `https://htmx.org/`
- **Horodatage** : 2026-10-26 12:48:05
- **URL testée** : https://htmx.org/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-48-05_EQUIPE_2_JS_htmx.org_.png` (7943.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-48-05_EQUIPE_2_JS_htmx.org_.png â€” 8134378 octets

2026-10-26T11:48:05.596488Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:48:05.863150Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=266
2026-10-26T11:48:05.866084Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=269
2026-10-26T11:48:06.689697Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1093
2026-10-26T11:48:06.694191Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=171362
2026-10-26T11:48:06.782097Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=87 ok=false
2026-10-26T11:48:06.796308Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=3293
2026-10-26T11:48:06.800854Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=4 ok=false
2026-10-26T11:48:06.801226Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=4752
2026-10-26T11:48:06.802204Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=false
2026-10-26T11:48:06.802725Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=101285
2026-10-26T11:48:06.865413Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=62 ok=true
2026-10-26T11:48:06.865469Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=287
2026-10-26T11:48:06.865727Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:48:06.869317Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:48:06.869382Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=NoBaseline
2026-10-26T11:48:06.869423Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:48:07.026143Z  INFO explorer_core::session::apply: apply: cascade ms=144
2026-10-26T11:48:07.044101Z  INFO explorer_core::session::apply: apply: boxtree ms=162
2026-10-26T11:48:07.455033Z  INFO explorer_core::session::apply: apply: layout ms=573
2026-10-26T11:48:07.867452Z  INFO explorer_core::session::apply: apply: repaint ms=986
2026-10-26T11:48:07.879759Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1010
2026-10-26T11:48:10.965917Z  INFO explorer_core::session::apply: apply: cascade ms=103
2026-10-26T11:48:10.977985Z  INFO explorer_core::session::apply: apply: boxtree ms=115
2026-10-26T11:48:11.032649Z  INFO explorer_core::session::apply: apply: layout ms=169
2026-10-26T11:48:11.396630Z  INFO explorer_core::session::apply: apply: repaint ms=533
[journal : 0 appliquÃ©s / 1 replis / 0 classÃ©es]
```

---

### ✈️ Vol #18 — `https://alpinejs.dev/`
- **Horodatage** : 2026-10-26 12:48:44
- **URL testée** : https://alpinejs.dev/
- **Statut final** : **🔴 FAIL**
- **Capture d'écran** : `captures/2026-10-26_12-48-44_EQUIPE_2_JS_alpinejs.dev_.png` (0.0 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
2026-10-26T11:48:44.212048Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:48:44.473860Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=261
2026-10-26T11:48:44.478074Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=266
2026-10-26T11:48:45.129796Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=917
2026-10-26T11:48:45.130578Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=208
2026-10-26T11:48:45.131021Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:48:45.131050Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=159822
2026-10-26T11:48:45.292676Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=161 ok=true
2026-10-26T11:48:45.292732Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=539
2026-10-26T11:48:45.293222Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:48:45.293249Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=133239
2026-10-26T11:48:45.426811Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=133 ok=true
2026-10-26T11:48:45.426867Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=320
2026-10-26T11:48:45.479772Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=52 ok=true
2026-10-26T11:48:45.479834Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2002
2026-10-26T11:48:45.482702Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=2 ok=true
2026-10-26T11:48:45.482758Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=929
2026-10-26T11:48:45.483486Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:48:45.483505Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=26051
2026-10-26T11:48:45.503865Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=20 ok=true
2026-10-26T11:48:45.503932Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=1448
2026-10-26T11:48:45.507088Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:48:45.507117Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=5451
2026-10-26T11:48:45.510258Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=3 ok=true
2026-10-26T11:48:45.510278Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=945
2026-10-26T11:48:45.510870Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:48:45.510887Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=2063
2026-10-26T11:48:45.516194Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=5 ok=true
2026-10-26T11:48:45.516228Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=38866
2026-10-26T11:48:45.583091Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=66 ok=true
2026-10-26T11:48:45.583153Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=15664
2026-10-26T11:48:45.594006Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=10 ok=true
2026-10-26T11:48:45.594067Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=41063
2026-10-26T11:48:45.610573Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=16 ok=true
2026-10-26T11:48:45.610636Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=55935

thread 'explorer-jscore' (20424) has overflowed its stack
```

---

### ✈️ Vol #19 — `https://preactjs.com/`
- **Horodatage** : 2026-10-26 12:50:36
- **URL testée** : https://preactjs.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-50-36_EQUIPE_2_JS_preactjs.com_.png` (11607.8 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-50-36_EQUIPE_2_JS_preactjs.com_.png â€” 11886345 octets

2026-10-26T11:50:36.735253Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:50:36.988004Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=252
2026-10-26T11:50:36.994436Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=259
2026-10-26T11:50:37.865165Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=1129
2026-10-26T11:50:37.866243Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=163
2026-10-26T11:50:37.867237Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:50:39.163279Z  INFO explorer_core::session::apply: apply: cascade ms=637
2026-10-26T11:50:39.452794Z  INFO explorer_core::session::apply: apply: boxtree ms=926
2026-10-26T11:50:40.229209Z  INFO explorer_core::session::apply: apply: layout ms=1703
2026-10-26T11:50:40.902893Z  INFO explorer_core::session::apply: apply: repaint ms=2376
2026-10-26T11:50:41.174695Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:50:41.176847Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=Fingerprint
2026-10-26T11:50:41.255241Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:50:41.960635Z  INFO explorer_core::session::apply: apply: cascade ms=673
2026-10-26T11:50:42.252486Z  INFO explorer_core::session::apply: apply: boxtree ms=965
2026-10-26T11:50:42.494106Z  INFO explorer_core::session::apply: apply: layout ms=1207
2026-10-26T11:50:43.091179Z  INFO explorer_core::session::apply: apply: repaint ms=1804
2026-10-26T11:50:43.170534Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1915
2026-10-26T11:50:43.173344Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:50:43.175362Z  WARN explorer_core::session::apply: journal DOM rejetÃ© â†’ repli re-parse (ADR-0025) tab=1 why=Fingerprint
2026-10-26T11:50:43.246653Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=false
2026-10-26T11:50:43.970034Z  INFO explorer_core::session::apply: apply: cascade ms=691
2026-10-26T11:50:44.259820Z  INFO explorer_core::session::apply: apply: boxtree ms=981
2026-10-26T11:50:44.486298Z  INFO explorer_core::session::apply: apply: layout ms=1208
2026-10-26T11:50:45.140436Z  INFO explorer_core::session::apply: apply: repaint ms=1862
2026-10-26T11:50:45.219680Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=1973
[journal : 0 appliquÃ©s / 2 replis / 0 classÃ©es]
```

---

### ✈️ Vol #20 — `https://svelte.dev/`
- **Horodatage** : 2026-10-26 12:51:22
- **URL testée** : https://svelte.dev/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-51-22_EQUIPE_2_JS_svelte.dev_.png` (8004.1 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-51-22_EQUIPE_2_JS_svelte.dev_.png â€” 8196154 octets

2026-10-26T11:51:22.647619Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:51:22.815905Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=168
2026-10-26T11:51:22.820859Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=173
2026-10-26T11:51:39.040703Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=16393
2026-10-26T11:51:39.041226Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=181
2026-10-26T11:51:39.041734Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:51:39.041781Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=304
2026-10-26T11:51:39.042032Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:51:39.042049Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=304
2026-10-26T11:51:39.042326Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:51:39.042341Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=409
2026-10-26T11:51:39.043103Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:51:39.043126Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=22804
2026-10-26T11:51:39.049531Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=6 ok=false
2026-10-26T11:51:39.050843Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=409
2026-10-26T11:51:39.051139Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=0 ok=true
2026-10-26T11:51:40.248946Z  INFO explorer_core::session::apply: apply: cascade ms=297
2026-10-26T11:51:40.473233Z  INFO explorer_core::session::apply: apply: boxtree ms=521
2026-10-26T11:51:40.720900Z  INFO explorer_core::session::apply: apply: layout ms=769
2026-10-26T11:51:41.589508Z  INFO explorer_core::session::apply: apply: repaint ms=1638
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #21 — `https://solidjs.com/`
- **Horodatage** : 2026-10-26 12:52:17
- **URL testée** : https://solidjs.com/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-52-17_EQUIPE_2_JS_solidjs.com_.png` (1156.7 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-52-17_EQUIPE_2_JS_solidjs.com_.png â€” 1184490 octets

2026-10-26T11:52:18.157086Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:52:18.444704Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=287
2026-10-26T11:52:18.445205Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=288
2026-10-26T11:52:20.723729Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=2566
2026-10-26T11:52:20.723985Z  INFO explorer_core::session::js_glue: script: evalâ€¦ tab=1 bytes=921
2026-10-26T11:52:20.725012Z  INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=1 ok=true
2026-10-26T11:52:21.619227Z DEBUG explorer_jscore::module: import() dynamique spec="./directory-229d4631-CtXb6iR0.js" referrer="https://www.solidjs.com/assets/index-By2yNLRO.js"
2026-10-26T11:52:21.619589Z DEBUG explorer_jscore::module: import() dynamique spec="./Home-DzraFOXr.js" referrer="https://www.solidjs.com/assets/index-By2yNLRO.js"
2026-10-26T11:52:21.868171Z  INFO explorer_core::session::apply: apply: cascade ms=161
2026-10-26T11:52:25.953697Z  INFO explorer_core::session::apply: apply: boxtree ms=4247
2026-10-26T11:52:25.957794Z  INFO explorer_core::session::apply: apply: layout ms=4251
2026-10-26T11:52:25.965829Z  INFO explorer_core::session::apply: apply: repaint ms=4259
2026-10-26T11:52:26.134596Z  INFO explorer_core::session::apply: apply: cascade ms=166
2026-10-26T11:52:26.135053Z  INFO explorer_core::session::apply: apply: boxtree ms=167
2026-10-26T11:52:26.135581Z  INFO explorer_core::session::apply: apply: layout ms=167
2026-10-26T11:52:26.136019Z  INFO explorer_core::session::apply: apply: repaint ms=168
2026-10-26T11:52:26.384087Z  INFO explorer_core::session::apply: apply: dÃ©but tab=1 journal=true
2026-10-26T11:52:26.915603Z  INFO explorer_core::session::apply: apply: fin tab=1 ms=531
[journal : 1 appliquÃ©s / 0 replis / 0 classÃ©es]
```

---

### ✈️ Vol #22 — `https://lit.dev/`
- **Horodatage** : 2026-10-26 12:53:02
- **URL testée** : https://lit.dev/
- **Statut final** : **🟢 OK**
- **Capture d'écran** : `captures/2026-10-26_12-53-02_EQUIPE_2_JS_lit.dev_.png` (1152.3 Ko)
- **Constat technique** : Rendu nominal réussi

#### 📋 Traces brutes & Diagnostic de vol :
```text
C:\OnionBit-Explorer\docs\Rapport vol\captures\2026-10-26_12-53-02_EQUIPE_2_JS_lit.dev_.png â€” 1180005 octets

2026-10-26T11:53:02.793890Z  INFO explorer_core::session::navigate: nav: fetch+parseâ€¦ tab=1
2026-10-26T11:53:03.107715Z  INFO explorer_core::session::navigate: nav: fetch+parse ok â†’ peinture tab=1 ms=313
2026-10-26T11:53:03.113022Z  INFO explorer_core::session::navigate: nav: peinture ok â†’ sous-ressources tab=1 ms=319
2026-10-26T11:53:07.919852Z  INFO explorer_core::session::navigate: nav: sous-ressources ok â†’ commit tab=1 ms=5125
2026-10-26T11:53:07.965149Z DEBUG explorer_jscore::dom_host: customElements.define name=litdev-code-language-switch
2026-10-26T11:53:07.981592Z DEBUG explorer_jscore::module: import() dynamique spec="../litdev-cookie-banner.js" referrer="https://lit.dev/js/global/hydrate-common-components.js"
2026-10-26T11:53:07.981808Z DEBUG explorer_jscore::module: import() dynamique spec="../lazy-svg.js" referrer="https://lit.dev/js/global/hydrate-common-components.js"
2026-10-26T11:53:07.981934Z DEBUG explorer_jscore::module: import() dynamique spec="../litdev-version-selector.js" referrer="https://lit.dev/js/global/hydrate-common-components.js"
2026-10-26T11:53:07.982059Z DEBUG explorer_jscore::module: import() dynamique spec="../theme-switcher.js" referrer="https://lit.dev/js/global/hydrate-common-components.js"
2026-10-26T11:53:08.706147Z  INFO explorer_core::session::apply: apply: cascade ms=569
2026-10-26T11:53:08.841693Z  INFO explorer_core::session::apply: apply: boxtree ms=704
2026-10-26T11:53:08.844891Z  INFO explorer_core::session::apply: apply: layout ms=707
2026-10-26T11:53:08.852317Z  INFO explorer_core::session::apply: apply: repaint ms=715
[journal : 0 appliquÃ©s / 0 replis / 0 classÃ©es]
```
