# 🛠️ DOSSIER D'INCIDENTS TECHNIQUES POUR L'AGENT 3 (FIXER JS & DOM)

**Priorité** : Critique  
**Crates concernés** : `crates/explorer-jscore` (moteur JS) et `crates/explorer-core` (session apply)  
**Règles du projet** : Respect strict de [AGENTS.md](file:///c:/OnionBit-Explorer%20-%20Copie/AGENTS.md) (`#![forbid(unsafe_code)]`, aucun `unwrap()`, approche TDD avec tests préalables).

---

## 🛑 INCIDENT #1 : Écrasement du `this` primitif en mode sloppy (`OrdinaryCallBindThis`)

### 1. Contexte & Sévérité
- **Sévérité** : 🔴 Bloquante (Casse l'ensemble des versions de **jQuery 1.x, 2.x, 3.x**, **Bootstrap**, et tout framework itérant sur des chaînes primitives).
- **Site détecteur** : `https://todomvc.com/`

### 2. Trace d'erreur capturée en vol
```text
DEBUG explorer_core::session::js_glue: script en échec tab=1 error=exception js : TypeError: `toLowerCase` is not a function (on Object)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:4:1681)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:2698)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:252)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:2)
```

### 3. Localisation exacte dans le code
Fichier : [`crates/explorer-jscore/src/interp/mod.rs`](file:///c:/OnionBit-Explorer%20-%20Copie/crates/explorer-jscore/src/interp/mod.rs#L5540-L5546)  
Fonction : `call_script_body`

```rust
// Code actuel défaillant :
let this = lex_this.unwrap_or(this);
let this = if lit.strict || matches!(this, Value::Obj(_)) {
    this
} else {
    Value::Obj(self.global) // ❌ ERREUR : remplace toute primitive par `window`
};
```

### 4. Explication de la spécification ECMAScript
Selon **ECMA-262 § 9.2.1.2 OrdinaryCallBindThis(F, calleeContext, thisArgument)** :
- Si la fonction est en mode strict : `thisValue = thisArgument`.
- Si la fonction est en mode sloppy (non-strict) :
  - Si `thisArgument` est `undefined` ou `null` : `thisValue = globalThis`.
  - Sinon : `thisValue = ToObject(thisArgument)` !
  - Pour une chaîne `"contentEditable"`, le moteur doit encapsuler la primitive dans un objet wrapper `String` (`self.protos.string` avec le slot `__prim`).

### 5. Test unitaire TDD à ajouter dans `crates/explorer-jscore/tests/`
```rust
#[test]
fn test_sloppy_this_primitive_boxing() {
    let mut engine = Engine::new();
    let res = engine.eval(r#"
        var out = (function() {
            return this.toLowerCase();
        }).call("HELLO_WORLD");
        out;
    "#).expect("evaluation failed");
    assert_eq!(res.to_string(), "hello_world");
}
```

---

## 🛑 INCIDENT #2 : Propriété `HTMLStyleElement.prototype.sheet` manquante

### 1. Contexte & Sévérité
- **Sévérité** : 🟠 Élevée (Casse les polyfills CSS dynamiques comme PrefixFree et les styles calculés par JS).
- **Site détecteur** : `https://todomvc.com/`

### 2. Trace d'erreur capturée en vol
```text
DEBUG explorer_core::session::js_glue: script en échec tab=1 error=exception js : TypeError: cannot read `cssRules` of Undefined
    at s (https://todomvc.com/bower_components/prefixfree/prefixfree.min.js:5:5533)
```

### 3. Localisation exacte
Fichier : [`crates/explorer-jscore/src/dom_host.rs`](file:///c:/OnionBit-Explorer%20-%20Copie/crates/explorer-jscore/src/dom_host.rs)  
Dans le getter de propriété d'éléments HTML :
Lors de l'accès à `"sheet"`, renvoyer l'objet `CSSStyleSheet` associé à l'élément `<style>` ou `<link rel="stylesheet">`.

---

## ⚠️ INCIDENT #3 : Rejets de Journal DOM (`UnmappedKey` / `NoBaseline`)

### 1. Contexte & Sévérité
- **Sévérité** : 🟡 Moyenne / Performance (Le moteur ne crashe pas, mais retombe sur un re-parse complet coûteux en CPU).
- **Sites détecteurs** : `developer.mozilla.org`, `lobste.rs`

### 2. Trace capturée
```text
WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=UnmappedKey
WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=NoBaseline
```

### 3. Localisation
Fichier : [`crates/explorer-core/src/session/apply.rs`](file:///c:/OnionBit-Explorer%20-%20Copie/crates/explorer-core/src/session/apply.rs)  
Optimiser le mapping de clés incrémentales pour éviter le déclenchement du repli ADR-0025.
