# 📜 Historique Général Permanent (Mode Append-Only - Aucun Écrasement)

Total des passages enregistrés : 101

| N° | Horodatage | Équipe | Site testé | Statut | Poids Frame | Observation / Mur détecté |
|:---:|:---:|:---|:---|:---:|:---:|:---|
| 1 | 2026-10-26 11:55:11 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 2 | 2026-10-26 11:55:11 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 3 | 2026-10-26 11:55:11 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 4 | 2026-10-26 11:55:11 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 5 | 2026-10-26 11:55:26 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 6 | 2026-10-26 11:55:26 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0 Ko | Ressource non trouvée / HTTP 404 |
| 7 | 2026-10-26 11:55:26 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 8 | 2026-10-26 11:55:26 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | Rendu nominal |
| 9 | 2026-10-26 11:56:50 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 10 | 2026-10-26 11:56:50 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 11 | 2026-10-26 11:56:50 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 12 | 2026-10-26 11:56:50 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 13 | 2026-10-26 11:57:18 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 14 | 2026-10-26 11:57:18 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 15 | 2026-10-26 11:57:18 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 16 | 2026-10-26 11:57:18 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 17 | 2026-10-26 11:57:54 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 18 | 2026-10-26 11:57:54 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 19 | 2026-10-26 11:57:54 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 20 | 2026-10-26 11:57:54 | Equipe_1_Docs | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5550 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 21 | 2026-10-26 11:58:13 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 22 | 2026-10-26 11:58:13 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 23 | 2026-10-26 11:58:13 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 24 | 2026-10-26 11:58:13 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175 Ko | Rendu nominal |
| 25 | 2026-10-26 11:59:41 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 26 | 2026-10-26 11:59:41 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0 Ko | Ressource non trouvée / HTTP 404 |
| 27 | 2026-10-26 11:59:41 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 28 | 2026-10-26 11:59:41 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 29 | 2026-10-26 11:59:56 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 30 | 2026-10-26 11:59:56 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 31 | 2026-10-26 11:59:56 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 32 | 2026-10-26 11:59:56 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 33 | 2026-10-26 12:00:16 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 34 | 2026-10-26 12:00:16 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 35 | 2026-10-26 12:00:16 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 36 | 2026-10-26 12:00:16 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | Rendu nominal |
| 37 | 2026-10-26 12:00:34 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 38 | 2026-10-26 12:00:34 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 39 | 2026-10-26 12:00:34 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 40 | 2026-10-26 12:00:34 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 41 | 2026-10-26 12:02:14 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 42 | 2026-10-26 12:02:14 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 43 | 2026-10-26 12:02:14 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 44 | 2026-10-26 12:02:14 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 45 | 2026-10-26 12:02:43 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 46 | 2026-10-26 12:02:43 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0 Ko | Ressource non trouvée / HTTP 404 |
| 47 | 2026-10-26 12:02:43 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 48 | 2026-10-26 12:02:43 | Equipe_1_Docs | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5549 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 49 | 2026-10-26 12:03:06 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 50 | 2026-10-26 12:03:06 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 51 | 2026-10-26 12:03:06 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 52 | 2026-10-26 12:03:06 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175 Ko | Rendu nominal |
| 53 | 2026-10-26 12:03:15 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 54 | 2026-10-26 12:03:15 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 55 | 2026-10-26 12:03:15 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 56 | 2026-10-26 12:03:15 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 57 | 2026-10-26 12:04:49 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 58 | 2026-10-26 12:04:49 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 59 | 2026-10-26 12:04:49 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 60 | 2026-10-26 12:04:49 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 61 | 2026-10-26 12:05:10 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 62 | 2026-10-26 12:05:10 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 63 | 2026-10-26 12:05:10 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 64 | 2026-10-26 12:05:10 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | Rendu nominal |
| 65 | 2026-10-26 12:05:35 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 66 | 2026-10-26 12:05:35 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0 Ko | Ressource non trouvée / HTTP 404 |
| 67 | 2026-10-26 12:05:35 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 68 | 2026-10-26 12:05:35 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 69 | 2026-10-26 12:06:00 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 70 | 2026-10-26 12:06:00 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 71 | 2026-10-26 12:06:00 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 72 | 2026-10-26 12:06:00 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 73 | 2026-10-26 12:07:35 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 74 | 2026-10-26 12:07:35 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 75 | 2026-10-26 12:07:35 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 76 | 2026-10-26 12:07:35 | Equipe_1_Docs | `https://lobste.rs/` | **⚠️ REPLI_DOM** | 5549.6 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 77 | 2026-10-26 12:07:59 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 78 | 2026-10-26 12:07:59 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 79 | 2026-10-26 12:07:59 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 80 | 2026-10-26 12:07:59 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175 Ko | Rendu nominal |
| 81 | 2026-10-26 12:08:24 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 82 | 2026-10-26 12:08:24 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 83 | 2026-10-26 12:08:24 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 84 | 2026-10-26 12:08:24 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 85 | 2026-10-26 12:08:37 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 86 | 2026-10-26 12:08:37 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0 Ko | Ressource non trouvée / HTTP 404 |
| 87 | 2026-10-26 12:08:37 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 88 | 2026-10-26 12:08:37 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 89 | 2026-10-26 12:10:02 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 90 | 2026-10-26 12:10:02 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 91 | 2026-10-26 12:10:02 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 92 | 2026-10-26 12:10:02 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.7 Ko | Rendu nominal |
| 93 | 2026-10-26 12:10:19 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 94 | 2026-10-26 12:10:19 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **⚠️ REPLI_DOM** | 6349 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 95 | 2026-10-26 12:10:19 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 96 | 2026-10-26 12:10:19 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 97 | 2026-10-26 12:10:56 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488 Ko | Rendu nominal |
| 98 | 2026-10-26 12:10:56 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **⚠️ REPLI_DOM** | 7851.2 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 99 | 2026-10-26 12:10:56 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 100 | 2026-10-26 12:10:56 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **⚠️ REPLI_DOM** | 7698.6 Ko | journal DOM rejeté → repli re-parse (ADR-0025) |
| 101 | 2026-10-26 12:11:22 | Equipe_4_Complex_Apps | `https://github.com/` | **🔴 FAIL** | 2910.4 Ko | Erreur de chargement |
| 8 | 2026-10-26 12:20:16 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 9 | 2026-10-26 12:21:37 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 10 | 2026-10-26 12:21:50 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 11 | 2026-10-26 12:21:51 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 12 | 2026-10-26 12:21:53 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 13 | 2026-10-26 12:22:05 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 14 | 2026-10-26 12:22:16 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 15 | 2026-10-26 12:22:22 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 16 | 2026-10-26 12:22:24 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 17 | 2026-10-26 12:22:40 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5513.7 Ko | Rendu nominal |
| 18 | 2026-10-26 12:22:45 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 19 | 2026-10-26 12:22:51 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 20 | 2026-10-26 12:22:52 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 21 | 2026-10-26 12:22:59 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 22 | 2026-10-26 12:23:00 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 23 | 2026-10-26 12:23:04 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 24 | 2026-10-26 12:23:05 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 25 | 2026-10-26 12:24:26 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 26 | 2026-10-26 12:24:28 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 27 | 2026-10-26 12:24:28 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 28 | 2026-10-26 12:24:31 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 29 | 2026-10-26 12:24:42 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 30 | 2026-10-26 12:24:43 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 31 | 2026-10-26 12:24:43 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 32 | 2026-10-26 12:24:45 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 33 | 2026-10-26 12:25:01 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3473.5 Ko | Rendu nominal |
| 34 | 2026-10-26 12:25:03 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 35 | 2026-10-26 12:25:10 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 36 | 2026-10-26 12:25:11 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 37 | 2026-10-26 12:25:19 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 38 | 2026-10-26 12:25:34 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 39 | 2026-10-26 12:25:40 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 40 | 2026-10-26 12:25:41 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 41 | 2026-10-26 12:27:03 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 42 | 2026-10-26 12:27:14 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 43 | 2026-10-26 12:27:19 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 44 | 2026-10-26 12:27:21 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 45 | 2026-10-26 12:27:32 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5513.6 Ko | Rendu nominal |
| 46 | 2026-10-26 12:27:37 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 47 | 2026-10-26 12:27:38 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 48 | 2026-10-26 12:27:39 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 49 | 2026-10-26 12:27:55 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 50 | 2026-10-26 12:27:56 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 51 | 2026-10-26 12:27:57 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 52 | 2026-10-26 12:27:58 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 53 | 2026-10-26 12:28:05 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 54 | 2026-10-26 12:28:06 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 55 | 2026-10-26 12:28:12 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 56 | 2026-10-26 12:28:13 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 57 | 2026-10-26 12:29:33 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 58 | 2026-10-26 12:29:34 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 59 | 2026-10-26 12:29:39 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 60 | 2026-10-26 12:29:42 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 61 | 2026-10-26 12:29:53 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3473.5 Ko | Rendu nominal |
| 62 | 2026-10-26 12:29:56 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 63 | 2026-10-26 12:30:00 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 64 | 2026-10-26 12:30:02 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 65 | 2026-10-26 12:30:19 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 66 | 2026-10-26 12:30:31 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 67 | 2026-10-26 12:30:31 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 68 | 2026-10-26 12:30:32 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 69 | 2026-10-26 12:30:40 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 70 | 2026-10-26 12:30:51 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 71 | 2026-10-26 12:30:52 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 72 | 2026-10-26 12:30:53 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 73 | 2026-10-26 12:32:12 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5543.2 Ko | Rendu nominal |
| 74 | 2026-10-26 12:32:17 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 75 | 2026-10-26 12:32:23 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 76 | 2026-10-26 12:32:26 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 77 | 2026-10-26 12:32:37 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 78 | 2026-10-26 12:32:38 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 79 | 2026-10-26 12:32:44 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 80 | 2026-10-26 12:32:46 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 81 | 2026-10-26 12:33:01 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 82 | 2026-10-26 12:33:03 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 83 | 2026-10-26 12:33:07 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 84 | 2026-10-26 12:33:08 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 85 | 2026-10-26 12:33:15 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 86 | 2026-10-26 12:33:16 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 87 | 2026-10-26 12:33:16 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 88 | 2026-10-26 12:33:17 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 89 | 2026-10-26 12:34:38 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 90 | 2026-10-26 12:34:41 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 91 | 2026-10-26 12:34:42 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 92 | 2026-10-26 12:34:45 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 93 | 2026-10-26 12:34:56 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 94 | 2026-10-26 12:35:08 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 95 | 2026-10-26 12:35:14 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 96 | 2026-10-26 12:35:16 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 97 | 2026-10-26 12:35:33 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 98 | 2026-10-26 12:35:45 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 99 | 2026-10-26 12:35:51 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 100 | 2026-10-26 12:35:53 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 101 | 2026-10-26 12:36:00 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5509.8 Ko | Rendu nominal |
| 102 | 2026-10-26 12:36:05 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 103 | 2026-10-26 12:36:10 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 104 | 2026-10-26 12:36:11 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 105 | 2026-10-26 12:37:32 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 106 | 2026-10-26 12:37:33 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 107 | 2026-10-26 12:37:33 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 108 | 2026-10-26 12:37:35 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 109 | 2026-10-26 12:37:46 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 110 | 2026-10-26 12:37:48 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 111 | 2026-10-26 12:37:49 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 112 | 2026-10-26 12:37:51 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 113 | 2026-10-26 12:38:07 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 114 | 2026-10-26 12:38:08 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 115 | 2026-10-26 12:38:14 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 116 | 2026-10-26 12:38:15 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 117 | 2026-10-26 12:38:22 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 118 | 2026-10-26 12:38:25 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 119 | 2026-10-26 12:38:31 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 120 | 2026-10-26 12:38:32 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 121 | 2026-10-26 12:39:54 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 122 | 2026-10-26 12:40:06 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 123 | 2026-10-26 12:40:11 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 124 | 2026-10-26 12:40:14 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 125 | 2026-10-26 12:40:25 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 126 | 2026-10-26 12:40:37 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 127 | 2026-10-26 12:40:38 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 128 | 2026-10-26 12:40:39 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 129 | 2026-10-26 12:40:57 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5544.6 Ko | Rendu nominal |
| 130 | 2026-10-26 12:41:02 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 131 | 2026-10-26 12:41:02 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 132 | 2026-10-26 12:41:04 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 133 | 2026-10-26 12:41:11 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 134 | 2026-10-26 12:41:12 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 135 | 2026-10-26 12:41:18 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 136 | 2026-10-26 12:41:19 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 137 | 2026-10-26 12:42:40 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 138 | 2026-10-26 12:42:41 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 139 | 2026-10-26 12:42:48 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 140 | 2026-10-26 12:42:50 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 141 | 2026-10-26 12:43:01 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 142 | 2026-10-26 12:43:02 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 143 | 2026-10-26 12:43:07 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 144 | 2026-10-26 12:43:08 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 145 | 2026-10-26 12:43:25 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 146 | 2026-10-26 12:43:28 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 147 | 2026-10-26 12:43:28 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 148 | 2026-10-26 12:43:29 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 149 | 2026-10-26 12:43:36 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 150 | 2026-10-26 12:43:48 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 151 | 2026-10-26 12:43:49 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 152 | 2026-10-26 12:43:51 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 153 | 2026-10-26 12:45:13 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 154 | 2026-10-26 12:45:24 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 155 | 2026-10-26 12:45:30 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 156 | 2026-10-26 12:45:33 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 157 | 2026-10-26 12:45:44 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5544.9 Ko | Rendu nominal |
| 158 | 2026-10-26 12:45:49 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 159 | 2026-10-26 12:45:55 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 160 | 2026-10-26 12:45:57 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 161 | 2026-10-26 12:46:13 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 162 | 2026-10-26 12:46:14 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 163 | 2026-10-26 12:46:18 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 164 | 2026-10-26 12:46:19 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 165 | 2026-10-26 12:46:27 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 166 | 2026-10-26 12:46:28 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 167 | 2026-10-26 12:46:28 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 168 | 2026-10-26 12:46:29 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 169 | 2026-10-26 12:47:50 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 170 | 2026-10-26 12:47:52 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 171 | 2026-10-26 12:47:52 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 172 | 2026-10-26 12:47:55 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 173 | 2026-10-26 12:48:06 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3473.0 Ko | Rendu nominal |
| 174 | 2026-10-26 12:48:09 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 175 | 2026-10-26 12:48:15 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 176 | 2026-10-26 12:48:17 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 177 | 2026-10-26 12:48:33 | Equipe_1_Docs | `https://en.wikipedia.org/wiki/Main_Page` | **🟢 OK** | 14222.1 Ko | Rendu nominal |
| 178 | 2026-10-26 12:48:46 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 179 | 2026-10-26 12:48:52 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 180 | 2026-10-26 12:48:53 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 181 | 2026-10-26 12:49:00 | Equipe_1_Docs | `https://developer.mozilla.org/en-US/` | **🟢 OK** | 7698.6 Ko | Rendu nominal |
| 182 | 2026-10-26 12:49:11 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 183 | 2026-10-26 12:49:15 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 184 | 2026-10-26 12:49:16 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 185 | 2026-10-26 12:50:37 | Equipe_1_Docs | `https://lobste.rs/` | **🟢 OK** | 5509.5 Ko | Rendu nominal |
| 186 | 2026-10-26 12:50:42 | Equipe_2_JS_SPA | `https://todomvc.com/examples/vanillajs/` | **🔴 FAIL** | 0.0 Ko | erreur : HTTP 404 |
| 187 | 2026-10-26 12:50:42 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 188 | 2026-10-26 12:50:45 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 189 | 2026-10-26 12:50:56 | Equipe_1_Docs | `https://info.cern.ch/` | **🟢 OK** | 1175.0 Ko | Rendu nominal |
| 190 | 2026-10-26 12:50:56 | Equipe_2_JS_SPA | `https://todomvc.com/examples/backbone/` | **🟢 OK** | 1165.4 Ko | Rendu nominal |
| 191 | 2026-10-26 12:50:57 | Equipe_3_Forms_Auth | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 192 | 2026-10-26 12:50:59 | Equipe_4_Complex_Apps | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 193 | 2026-10-26 12:51:15 | Equipe_1_Docs | `https://text.npr.org/` | **🟢 OK** | 2316.9 Ko | Rendu nominal |
| 194 | 2026-10-26 12:51:16 | Equipe_2_JS_SPA | `https://danilowoz.com/` | **🟢 OK** | 6349.0 Ko | Rendu nominal |
| 195 | 2026-10-26 12:51:22 | Equipe_3_Forms_Auth | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 196 | 2026-10-26 12:51:24 | Equipe_4_Complex_Apps | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 197 | 2026-10-26 12:51:32 | Equipe_1_Docs | `https://example.com/` | **🟢 OK** | 1259.9 Ko | Rendu nominal |
| 198 | 2026-10-26 12:51:33 | Equipe_2_JS_SPA | `https://v2.vuejs.org/` | **🟢 OK** | 7851.2 Ko | Rendu nominal |
| 199 | 2026-10-26 12:51:38 | Equipe_3_Forms_Auth | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 200 | 2026-10-26 12:51:39 | Equipe_4_Complex_Apps | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 201 | 2026-10-26 12:53:02 | Equipe_1_Docs | `https://news.ycombinator.com/` | **🟢 OK** | 3472.9 Ko | Rendu nominal |
| 202 | 2026-10-26 12:53:06 | Equipe_2_JS_SPA | `https://todomvc.com/` | **🟢 OK** | 11267.2 Ko | Rendu nominal |
| 203 | 2026-10-26 12:53:11 | Equipe_3_Forms_Auth | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 204 | 2026-10-26 12:53:14 | Equipe_4_Complex_Apps | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
