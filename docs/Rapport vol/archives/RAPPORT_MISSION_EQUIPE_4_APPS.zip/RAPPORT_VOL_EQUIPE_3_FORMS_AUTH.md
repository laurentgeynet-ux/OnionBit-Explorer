# 📜 Journal de Vol Permanent & Fiches Détaillées : Équipe 3 (Formulaires & Auth)

*Ce document conserve l'intégralité des vols sans jamais rien écraser. Chaque vol ajoute sa ligne au tableau récapitulatif ET sa fiche technique détaillée ci-dessous.*

---

## 📊 Tableau Récapitulatif Chronologique (25 vols)

| N° | Horodatage | Site internet | Statut | Poids Frame | Diagnostic / Observation |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 11:55:11 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #1](#vol-1--hn-login) — Formulaire de connexion/inscription OK |
| 2 | 2026-10-26 11:55:26 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | [Voir Détail #2](#vol-2--httpbin-forms) — Formulaire complet HTML5 (inputs, radios, textareas) |
| 3 | 2026-10-26 11:56:50 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | [Voir Détail #3](#vol-3--duckduckgo-html) — Champ de recherche et bouton de recherche |
| 4 | 2026-10-26 11:57:18 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | [Voir Détail #4](#vol-4--lobsters-login) — Formulaire d'authentification CSRF |
| 5 | 2026-10-26 11:57:54 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #5](#vol-5--hn-login) — Rendu nominal |
| 6 | 2026-10-26 11:58:13 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | [Voir Détail #6](#vol-6--httpbin-forms) — Rendu nominal |
| 7 | 2026-10-26 11:59:41 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | [Voir Détail #7](#vol-7--duckduckgo-html) — Rendu nominal |
| 8 | 2026-10-26 11:59:56 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | [Voir Détail #8](#vol-8--lobsters-login) — Rendu nominal |
| 9 | 2026-10-26 12:00:16 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #9](#vol-9--hn-login) — Rendu nominal |
| 10 | 2026-10-26 12:00:34 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | [Voir Détail #10](#vol-10--httpbin-forms) — Rendu nominal |
| 11 | 2026-10-26 12:02:14 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | [Voir Détail #11](#vol-11--duckduckgo-html) — Rendu nominal |
| 12 | 2026-10-26 12:02:43 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | [Voir Détail #12](#vol-12--lobsters-login) — Rendu nominal |
| 13 | 2026-10-26 12:03:06 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #13](#vol-13--hn-login) — Rendu nominal |
| 14 | 2026-10-26 12:03:15 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | [Voir Détail #14](#vol-14--httpbin-forms) — Rendu nominal |
| 15 | 2026-10-26 12:04:49 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | [Voir Détail #15](#vol-15--duckduckgo-html) — Rendu nominal |
| 16 | 2026-10-26 12:05:10 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | [Voir Détail #16](#vol-16--lobsters-login) — Rendu nominal |
| 17 | 2026-10-26 12:05:35 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #17](#vol-17--hn-login) — Rendu nominal |
| 18 | 2026-10-26 12:06:00 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | [Voir Détail #18](#vol-18--httpbin-forms) — Rendu nominal |
| 19 | 2026-10-26 12:07:35 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | [Voir Détail #19](#vol-19--duckduckgo-html) — Rendu nominal |
| 20 | 2026-10-26 12:07:59 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | [Voir Détail #20](#vol-20--lobsters-login) — Rendu nominal |
| 21 | 2026-10-26 12:08:24 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #21](#vol-21--hn-login) — Rendu nominal |
| 22 | 2026-10-26 12:08:37 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | [Voir Détail #22](#vol-22--httpbin-forms) — Rendu nominal |
| 23 | 2026-10-26 12:10:02 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | [Voir Détail #23](#vol-23--duckduckgo-html) — Rendu nominal |
| 24 | 2026-10-26 12:10:19 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | [Voir Détail #24](#vol-24--lobsters-login) — Rendu nominal |
| 25 | 2026-10-26 12:10:56 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | [Voir Détail #25](#vol-25--hn-login) — Rendu nominal |

---

## 🔍 Fiches Techniques Détaillées des Vols

### <a id="vol-1--hn-login"></a>Vol #1 — `https://news.ycombinator.com/login` (2026-10-26 11:55:11)
- **Cible** : Page de connexion / inscription Hacker News
- **Statut** : 🟢 OK
- **Poids Frame** : 1 173.5 Ko
- **Temps commit** : 700 ms
- **Analyse technique** : Présence de deux éléments `<form>` distincts. Les boîtes de saisie `<input type="text">` et `<input type="password">` sont peintes avec leurs bordures natives. L'arbre de layout `BoxTree` attribue correctement les géométries de focus.

---

### <a id="vol-2--httpbin-forms"></a>Vol #2 — `https://httpbin.org/forms/post` (2026-10-26 11:55:26)
- **Cible** : Formulaire HTML5 de référence HTTPBin
- **Statut** : 🟢 OK
- **Poids Frame** : 1 181.5 Ko
- **Analyse technique** : Tous les types de contrôles sont testés simultanément :
  - Cases à cocher `<input type="checkbox">`
  - Boutons radio `<input type="radio">`
  - Champ texte multi-lignes `<textarea>`
  - Inputs spécialisés `<input type="email">`, `<input type="tel">`
  Le rendu ne produit aucune erreur dans `explorer-layout`.
| 2026-10-26 12:25:40 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:27:19 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:27:38 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:27:57 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:28:12 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:29:39 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:30:00 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:30:31 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:30:52 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:32:23 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:32:44 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:33:07 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:33:16 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:34:42 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:35:14 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:35:51 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:36:10 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:37:33 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:37:49 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:38:14 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:38:31 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:40:11 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:40:38 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:41:02 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:41:18 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:42:48 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:43:07 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:43:28 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:43:49 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:45:30 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:45:55 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:46:18 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:46:28 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:47:52 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:48:15 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:48:52 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:49:15 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:50:42 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
| 2026-10-26 12:50:57 | `https://lobste.rs/login` | **🟢 OK** | 1215.1 Ko | Rendu nominal |
| 2026-10-26 12:51:22 | `https://news.ycombinator.com/login` | **🟢 OK** | 1173.5 Ko | Rendu nominal |
| 2026-10-26 12:51:38 | `https://httpbin.org/forms/post` | **🟢 OK** | 1181.5 Ko | Rendu nominal |
| 2026-10-26 12:53:11 | `https://html.duckduckgo.com/html/` | **🟢 OK** | 2274.8 Ko | Rendu nominal |
