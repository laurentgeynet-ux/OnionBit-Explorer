# Rapport de Vol — Équipe 2 : SPAs, Frameworks & Bibliothèques JS

- **Équipe** : Vol Bravo (Éclaireurs JavaScript)
- **Cible principale** : `https://todomvc.com/` (Stack Vanilla JS, jQuery 2.1.4, PrefixFree, Bootstrap)
- **Objectif** : Vérifier la chaîne d'exécution JS complète et l'interactivité.

---

## 🛑 Mur #1 (Critique) : Régression dans `OrdinaryCallBindThis` (sloppy)

### 1. Description
Lors de l'initialisation de jQuery 2.1.4, une boucle `each` itère sur des noms de propriétés CSS :
```javascript
jQuery.each([
    "tabIndex", "readOnly", "maxLength", "cellSpacing",
    "cellPadding", "rowSpan", "colSpan", "useMap",
    "frameBorder", "contentEditable"
], function() {
    jQuery.propFix[this.toLowerCase()] = this;
});
```
La fonction de rappel est appelée via `Function.prototype.call(val, index, val)`.
Dans cette fonction, `this` est la chaîne de caractères `"contentEditable"`.

### 2. Trace d'exécution relevée
```text
2026-10-26T10:44:31.048077Z INFO explorer_core::session::js_glue: script: eval fin tab=1 ms=452 ok=false
2026-10-26T10:44:31.048125Z DEBUG explorer_core::session::js_glue: script en échec tab=1 error=exception js : TypeError: `toLowerCase` is not a function (on Object)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:4:1681)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:2698)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:252)
    at <anonymous> (https://todomvc.com/bower_components/jquery/dist/jquery.min.js:2:2)
```

### 3. Diagnostic Code
Dans `crates/explorer-jscore/src/interp/mod.rs` (fonction `call_script_body`) :
```rust
let this = lex_this.unwrap_or(this);
let this = if lit.strict || matches!(this, Value::Obj(_)) {
    this
} else {
    Value::Obj(self.global)
};
```
Comme `this` vaut `Value::Str(...)`, `matches!(this, Value::Obj(_))` est faux.
Le code affecte donc `Value::Obj(self.global)` (`window`).
Puis `this.toLowerCase()` est résolu en `window.toLowerCase()`, qui renvoie `Undefined` et déclenche `TypeError`.

### 4. Reproduction Minimale (Test Fixture)
```javascript
var res = (function() {
    return this.toLowerCase();
}).call("FOOBAR");
if (res !== "foobar") throw new Error("this n'a pas été boxé correctement");
```

---

## 🛑 Mur #2 (Moyen) : Absence de `HTMLStyleElement.prototype.sheet`

### 1. Description
La bibliothèque `prefixfree.min.js` parcourt les éléments `<style>` et `<link rel="stylesheet">` du document et inspecte leurs règles CSS via `element.sheet.cssRules`.

### 2. Trace d'exécution relevée
```text
2026-10-26T10:44:30.595549Z DEBUG explorer_core::session::js_glue: script en échec tab=1 error=exception js : TypeError: cannot read `cssRules` of Undefined
    at s (https://todomvc.com/bower_components/prefixfree/prefixfree.min.js:5:5533)
```

### 3. Diagnostic Code
Dans `crates/explorer-jscore/src/dom_host.rs`, les propriétés exposées pour les éléments HTML ne comprennent pas encore `"sheet"`.

### 4. Reproduction Minimale (Test Fixture)
```javascript
var style = document.createElement("style");
document.head.appendChild(style);
if (!style.sheet || typeof style.sheet.cssRules === "undefined") {
    throw new Error("style.sheet est manquant");
}
```

---

## 🎯 Consignes de transmission pour l'Agent 3 (Fixer)
- Crate ciblé : `explorer-jscore`
- Fichiers à modifier :
  1. `crates/explorer-jscore/src/interp/mod.rs` (Boxing du `this` primitif en sloppy).
  2. `crates/explorer-jscore/src/dom_host.rs` (Getter `"sheet"` sur les éléments de style).
- Critère de validation : `cargo test -p explorer-jscore` + traversée réussie de `https://todomvc.com/`.
