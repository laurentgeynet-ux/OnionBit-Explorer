# 📜 Journal de Vol Permanent & Fiches Détaillées : Équipe 4 (Complex Apps & Web Components)

*Ce document conserve l'intégralité des vols sans jamais rien écraser. Chaque vol ajoute sa ligne au tableau récapitulatif ET sa fiche technique détaillée ci-dessous.*

---

## 📊 Tableau Récapitulatif Chronologique (25 vols)

| N° | Horodatage | Site internet | Statut | Poids Frame | Diagnostic / Observation |
|:---:|:---:|:---|:---:|:---:|:---|
| 1 | 2026-10-26 11:55:11 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #1](#vol-1--2048game) — Boucle de jeu HTML5 & animations peintes |
| 2 | 2026-10-26 11:55:26 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | [Voir Détail #2](#vol-2--github) — >40 Web Components & dynamic import() ESM |
| 3 | 2026-10-26 11:56:50 | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | [Voir Détail #3](#vol-3--w3c) — journal DOM rejeté why=NoBaseline |
| 4 | 2026-10-26 11:57:18 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | [Voir Détail #4](#vol-4--stallman) — Arbre DOM géant (>25 Mo de frame rasterisée) |
| 5 | 2026-10-26 11:57:54 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #5](#vol-5--2048game) — Rendu nominal |
| 6 | 2026-10-26 11:58:13 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | [Voir Détail #6](#vol-6--github) — Rendu nominal |
| 7 | 2026-10-26 11:59:41 | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | [Voir Détail #7](#vol-7--w3c) — journal DOM rejeté why=NoBaseline |
| 8 | 2026-10-26 11:59:56 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | [Voir Détail #8](#vol-8--stallman) — Rendu nominal |
| 9 | 2026-10-26 12:00:16 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #9](#vol-9--2048game) — Rendu nominal |
| 10 | 2026-10-26 12:00:34 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | [Voir Détail #10](#vol-10--github) — Rendu nominal |
| 11 | 2026-10-26 12:02:14 | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | [Voir Détail #11](#vol-11--w3c) — journal DOM rejeté why=NoBaseline |
| 12 | 2026-10-26 12:02:43 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | [Voir Détail #12](#vol-12--stallman) — Rendu nominal |
| 13 | 2026-10-26 12:03:06 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #13](#vol-13--2048game) — Rendu nominal |
| 14 | 2026-10-26 12:03:15 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | [Voir Détail #14](#vol-14--github) — Rendu nominal |
| 15 | 2026-10-26 12:04:49 | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | [Voir Détail #15](#vol-15--w3c) — journal DOM rejeté why=NoBaseline |
| 16 | 2026-10-26 12:05:10 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | [Voir Détail #16](#vol-16--stallman) — Rendu nominal |
| 17 | 2026-10-26 12:05:35 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #17](#vol-17--2048game) — Rendu nominal |
| 18 | 2026-10-26 12:06:00 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | [Voir Détail #18](#vol-18--github) — Rendu nominal |
| 19 | 2026-10-26 12:07:35 | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | [Voir Détail #19](#vol-19--w3c) — journal DOM rejeté why=NoBaseline |
| 20 | 2026-10-26 12:07:59 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | [Voir Détail #20](#vol-20--stallman) — Rendu nominal |
| 21 | 2026-10-26 12:08:24 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #21](#vol-21--2048game) — Rendu nominal |
| 22 | 2026-10-26 12:08:37 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | [Voir Détail #22](#vol-22--github) — Rendu nominal |
| 23 | 2026-10-26 12:10:02 | `https://w3c.github.io/` | **⚠️ REPLI_DOM** | 6485.3 Ko | [Voir Détail #23](#vol-23--w3c) — journal DOM rejeté why=NoBaseline |
| 24 | 2026-10-26 12:10:19 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | [Voir Détail #24](#vol-24--stallman) — Rendu nominal |
| 25 | 2026-10-26 12:10:56 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | [Voir Détail #25](#vol-25--2048game) — Rendu nominal |

---

## 🔍 Fiches Techniques Détaillées des Vols

### <a id="vol-1--2048game"></a>Vol #1 — `https://2048game.com/` (2026-10-26 11:55:11)
- **Cible** : Jeu 2048 HTML5
- **Statut** : 🟢 OK
- **Poids Frame** : 3 488.0 Ko
- **Temps commit** : 863 ms
- **Analyse technique** : Évaluation complète des scripts de jeu (12 332 octets) en 54 ms. Les transformations CSS `translate3d` pour le glissement des tuiles et les listeners clavier sont fonctionnels.

---

### <a id="vol-2--github"></a>Vol #2 — `https://github.com/` (2026-10-26 11:55:26)
- **Cible** : GitHub.com
- **Statut** : 🟢 OK
- **Poids Frame** : 2 910.4 Ko
- **Analyse technique & Prouesse** :
  - **Custom Elements** : Plus de 40 composants Web enregistrés via `customElements.define` (`relative-time`, `action-bar`, `modal-dialog`, `tab-container`, etc.).
  - **Modules ESM Dynamiques** : Chargement et résolution en temps réel de dizaines de chunks via `import()` dynamique dans `explorer_jscore::module`.
  - **Comportement du Layout** : Pipeline de rendu achevé sans overflow non géré.

---

### <a id="vol-3--w3c"></a>Vol #3 — `https://w3c.github.io/` (2026-10-26 11:56:50)
- **Cible** : Spécifications W3C
- **Statut** : ⚠️ REPLI_DOM
- **Poids Frame** : 6 485.3 Ko
- **Trace interceptée** :
  ```text
  WARN explorer_core::session::apply: journal DOM rejeté → repli re-parse (ADR-0025) tab=1 why=NoBaseline
  ```
- **Diagnostic** : Le journal incrémental se replie sur un re-parse automatique. Frame finale intègre.

---

### <a id="vol-4--stallman"></a>Vol #4 — `https://stallman.org/` (2026-10-26 11:57:18)
- **Cible** : Site documentaire Richard Stallman
- **Statut** : 🟢 OK
- **Poids Frame** : 25 967.1 Ko (Document géant)
- **Analyse technique** : La hauteur du document dépasse les 25 Mo de framebuffer. Aucune panique mémoire dans `tiny-skia` ou `explorer-layout`.
| 2026-10-26 12:25:41 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:27:21 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:27:39 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:27:58 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:28:13 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:29:42 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:30:02 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:30:32 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:30:53 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:32:26 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:32:46 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:33:08 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:33:17 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:34:45 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:35:16 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:35:53 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:36:11 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:37:35 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:37:51 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:38:15 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:38:32 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:40:14 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:40:39 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:41:04 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:41:19 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:42:50 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:43:08 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:43:29 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:43:51 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:45:33 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:45:57 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:46:19 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:46:29 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:47:55 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:48:17 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:48:53 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:49:16 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:50:45 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
| 2026-10-26 12:50:59 | `https://stallman.org/` | **🟢 OK** | 25967.1 Ko | Rendu nominal |
| 2026-10-26 12:51:24 | `https://2048game.com/` | **🟢 OK** | 3488.0 Ko | Rendu nominal |
| 2026-10-26 12:51:39 | `https://github.com/` | **🟢 OK** | 2910.4 Ko | Rendu nominal |
| 2026-10-26 12:53:14 | `https://w3c.github.io/` | **🟢 OK** | 6485.3 Ko | Rendu nominal |
